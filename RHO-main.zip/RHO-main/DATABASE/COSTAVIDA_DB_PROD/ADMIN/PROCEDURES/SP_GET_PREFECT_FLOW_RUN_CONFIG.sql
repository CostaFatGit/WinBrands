-- PROCEDURES: SP_GET_PREFECT_FLOW_RUN_CONFIG
-- Generated on: 2025-06-05 11:43:33
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_GET_PREFECT_FLOW_RUN_CONFIG"()
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
      result_set RESULTSET;
      seq_key INT;
      
BEGIN 

    SELECT 
      RAW.SEQ_PREFECT_FLOW_RUN.NEXTVAL 
    INTO 
      :seq_key;

    result_set :=
    (
        SELECT
          ACCOUNT_ID
         ,WORKSPACE_ID
         ,:seq_key AS RUN_ID
         ,API_ENDPOINT
         ,API_KEY
         ,CONCAT(''https://api.prefect.cloud/api/accounts/'', ACCOUNT_ID,''/workspaces/'', WORKSPACE_ID, API_ENDPOINT) AS API_URL
         ,ENABLED_DATE_TIME
         ,CASE WHEN ENABLED_DATE_TIME <= CURRENT_TIMESTAMP() THEN TRUE ELSE FALSE END AS IS_ENABLED
        FROM
          ADMIN.PREFECT_FLOW_RUN_CONFIG
        WHERE
          ENABLED_DATE_TIME <= CURRENT_TIMESTAMP()
    );

    RETURN TABLE(result_set);

END';
