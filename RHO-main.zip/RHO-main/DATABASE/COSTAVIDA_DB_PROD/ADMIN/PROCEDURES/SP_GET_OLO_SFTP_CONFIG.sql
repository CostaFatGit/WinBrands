-- PROCEDURES: SP_GET_OLO_SFTP_CONFIG
-- Generated on: 2025-06-05 11:43:32
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_GET_OLO_SFTP_CONFIG"()
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
      result_set RESULTSET;
      seq_key INT;
      
BEGIN

  SELECT 
    RAW.SEQ_OLO_PAY_TRANSACTION.NEXTVAL 
  INTO 
    :seq_key;
    
    result_set := (
        SELECT
          O.HOST_NAME
         ,O.USER_NAME
         ,O.SSH_KEY
         ,:seq_key AS RUN_ID
        FROM
          ADMIN.OLO_SFTP_CONFIG O
        WHERE
          ENABLED_DATE_TIME <= CURRENT_TIMESTAMP()
    );

    RETURN TABLE(result_set);

END';
