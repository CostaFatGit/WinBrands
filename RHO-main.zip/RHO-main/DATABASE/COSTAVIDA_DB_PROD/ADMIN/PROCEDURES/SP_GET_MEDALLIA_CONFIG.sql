-- PROCEDURES: SP_GET_MEDALLIA_CONFIG
-- Generated on: 2025-06-05 11:43:32
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_GET_MEDALLIA_CONFIG"()
RETURNS TABLE ("E_RESPONSEDATE" VARCHAR(16777216), "a_surveyid" VARCHAR(16777216))
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  result_set RESULTSET;
  
BEGIN 

  result_set := (
                    SELECT TOP 1
                      DT.E_RESPONSEDATE
                     ,DT.A_SURVEYID
                    FROM
                    (
                        SELECT
                          O.value:e_responsedate.values[0]::STRING AS E_RESPONSEDATE
                         ,O.ID AS A_SURVEYID
                        FROM
                          LOAD.RAW_MEDALLIA_VOC_SURVEY O
                        WHERE
                          O.value:e_responsedate.values[0]::STRING IS NOT NULL
                        UNION
                        SELECT
                          E_RESPONSEDATE:values[0]::STRING AS E_RESPONSEDATE
                         ,ID AS A_SURVEYID
                        FROM
                          LOAD.RAW_MEDALLIA_QUERYAPI_CV_VOC_SURVEY N
                        UNION
                        SELECT
                          ''2022-01-01 00:00:00'' AS E_RESPONSEDATE
                         ,''0'' AS A_SURVEYID
                    ) DT
                    ORDER BY
                      TO_TIMESTAMP_NTZ(DT.E_RESPONSEDATE) DESC
                     ,DT.A_SURVEYID DESC
  );

  RETURN TABLE(result_set);

END;
';
