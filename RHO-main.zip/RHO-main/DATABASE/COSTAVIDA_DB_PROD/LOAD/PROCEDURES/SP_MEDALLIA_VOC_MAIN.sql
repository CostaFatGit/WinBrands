-- PROCEDURES: SP_MEDALLIA_VOC_MAIN
-- Generated on: 2025-06-05 11:43:34
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_MEDALLIA_VOC_MAIN"()
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    flat_tbl VARCHAR default ''flat_medallia_voc_temp'';
    load_stream VARCHAR default ''LOAD_MEDALLIA_VOC_SURVEY_STREAM'';
    raw_tbl VARCHAR default ''raw_medallia_voc_temp'';
    rs RESULTSET DEFAULT (select system$stream_has_data(:load_stream) as col);
    csr CURSOR for rs;
    has_data BOOLEAN;
    
BEGIN
    -- NOTE: Medallia reports times in Mountain Time with not timezone. Set session timezone to MT prior to executing (alter session set timezone = ''America/Denver'';)
    FOR thisrow IN csr DO
        has_data := thisrow.col;
    END FOR;

    -- IF (has_data) THEN
    IF (true) THEN
        -- There are new records in the stream to process

        -- Data from the stream of raw data must be processed all the way into the fact_feedback table or rolled back as a single ACID transaction
        BEGIN TRANSACTION; 

        -- Create a temporary table for flattened JSON
        create or replace temporary table identifier(:flat_tbl) (
            id VARCHAR,
            e_status VARCHAR,
            e_creation_date VARCHAR,
            e_response_date VARCHAR,
            e_cv_feedback_program_enum VARCHAR,
            e_cv_survey_type_enum VARCHAR,
            e_unitid VARCHAR,
            e_cv_voc_posref_txt VARCHAR,
            q_cv_voc_receipt_code_check_num_txt VARCHAR,
            q_cv_voc_receipt_code_datetime_txt VARCHAR,
            e_cv_voc_time_placed_date_time VARCHAR,
            q_costavida_voc_visit_day_date VARCHAR,
            q_costavida_day_part_enum VARCHAR,
            feedback_item VARCHAR,
            feedback_selection VARCHAR,
            is_comment BOOLEAN
        );

        -- empty the raw stream into a temp table, so it can be processed through multiple DML steps
        -- create or replace temporary table identifier(:raw_tbl) as select * from identifier(:load_stream);

        create or replace temporary table identifier(:raw_tbl) 
        as select DISTINCT ab."_airbyte_data"
        from identifier(:load_stream) s
            join load."LOAD_raw__stream_raw_medallia_queryapi_cv_voc_survey" ab
        on ab."_airbyte_raw_id" = s._airbyte_raw_id
        where metadata$action = ''INSERT'';

        -- delete from fact_feedback where feedback_response_time > ''2024-06-10''::timestamp_ltz;
        -- create or replace temporary table identifier(:raw_tbl) as select * from raw_medallia_voc_survey where e_responsedate > ''2024-06-10''::timestamp_ltz;

        -- Flatten JSON surveys to a new record for question. A new record is created for each selection in a multi-valued response. 
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_catering_order_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_catering_order_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_food_quality_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_food_quality_detail_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_food_quality_detail_mv_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_issue_type_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_order_accuracy_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_order_accuracy_detail_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_order_accuracy_detail_mv_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ordering_process_detail_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ordering_process_detail_mv_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_restaurant_cleanliness_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_restaurant_cleanliness_detail_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_restaurant_cleanliness_detail_mv_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_value_detail_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_value_detail_mv_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_accuracy_of_order_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_accuracy_of_order_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_cleanliness_of_restaurant_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_curbside_order_method_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_customer_contact_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_delivery_order_method_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_dining_type_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_flex_survey_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_food_quality_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_friendliness_of_team_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_greet_guest_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_issue_experienced_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_issue_resolution_satisfaction_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_issue_type_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_likelihood_to_recommend_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_likelihood_to_recommend_restaurant_scale11'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_menu_knowledge_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_number_of_visits_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_order_method_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ordering_process_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ordering_process_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_overall_satisfaction_restaurant_scale5'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_restaurant_cleanliness_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_service_comments_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_speed_of_service_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_take_out_order_method_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_thank_guest_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_value_detail_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_value_scale6'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_verify_order_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_visit_table_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ltr_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_ltr_and_osat_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_additional_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_complaint_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_complaint_other_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_general_information_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_general_information_other_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_web_provide_feedback_type_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_wev_compliment_category_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_costavida_voc_wev_compliment_category_other_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_bp_htl_ltr_cmt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_pacakges_bp_htl_osat_scale'', false);
        --- Adds for June 2025 Medallia survey change
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_overall_experience_scale5'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_dining_option_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_overall_experience_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_issue_experienced_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_type_of_issue_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_order_issue_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_order_issue_other_txt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_order_issue_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_staff_issue_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_staff_issue_other_txt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_staff_issue_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_facilities_issue_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_facilities_issue_other_txt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_facilities_issue_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_appweb_issue_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_app_web_other_txt'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_app_web_issue_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_catering_order_issue_enum'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_catering_order_issue_comment'', true);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_contact_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_promoter_flex_yn'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''q_cv_voc_type_promoter_feedback_multi'', false);
        call sp_medallia_voc_raw_to_flat_feedback(:raw_tbl, :flat_tbl, ''a_has_open_alert'', false);

        -- Add any new dim_feedback_type dimension records found in the flattened data before inserting facts
        call sp_medallia_voc_flat_to_feedback_type(:flat_tbl);
        CALL LOAD.SP_MEDALLIA_FIELDS_TO_DIM_FEEDBACK_TYPE();

        -- Insert new facts from flattened records linked to dimensions
        call sp_medallia_voc_flat_to_fact_feedback(:flat_tbl);

        -- Cleanup temp tables (for cleanliness only, they will be deleted at the end of the session)
        drop table identifier(:raw_tbl);
        drop table identifier(:flat_tbl);

        --Delete duplicates until we find where they are coming from.  Just a bandaid fix.
        DELETE FROM
          PUBLIC.FACT_FEEDBACK
        WHERE
          FEEDBACK_KEY IN (SELECT
                             FEEDBACK_KEY
                           FROM
                           (
                            SELECT
                              SOURCE_FEEDBACK_ID
                             ,FEEDBACK_TYPE_KEY
                             ,FEEDBACK_KEY
                             ,ROW_NUMBER() OVER(PARTITION BY SOURCE_FEEDBACK_ID, FEEDBACK_TYPE_KEY ORDER BY FEEDBACK_KEY ASC) RN
                            FROM
                              PUBLIC.FACT_FEEDBACK
                            WHERE
                              SOURCE_FEEDBACK_ID IS NOT NULL
                              AND FEEDBACK_TYPE_KEY IS NOT NULL
                            ) DT
                            WHERE
                              RN <> 1
                          );
        
        COMMIT;

        RETURN true;
        
        -- EXCEPTION
        --     WHEN OTHER THEN ROLLBACK;
        --     RAISE;
    ELSE
        -- There are no new records in the stream
        RETURN false;
    END IF;
END;
';
