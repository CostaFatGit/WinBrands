-- PROCEDURES: SP_MEDALLIA_VOC_FLAT_TO_FACT_FEEDBACK
-- Generated on: 2025-06-05 11:43:34
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_MEDALLIA_VOC_FLAT_TO_FACT_FEEDBACK"("FLAT_TABLE" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
  BEGIN
    insert into public.fact_feedback 
    (
        source_feedback_id, 
        comment,
        feedback_created_time,
        feedback_response_time,
        pos_order_id,
        order_number,
        order_date,
        feedback_type_key,
        restaurant_key,
        response_date_key,
        order_date_key,
        order_time_key
    )
    select distinct
      f.id as source_feedback_id,
      iff(f.is_comment, f.feedback_selection, NULL) as comment,
      f.e_creation_date::timestamp_ltz as feedback_created_time,
      f.e_response_date::timestamp_ltz as feedback_response_time,
      f.e_cv_voc_posref_txt as pos_order_id, -- TODO: Lookup Q_CV_VOC_RECEIPT_CODE_CHECK_NUM_TXT to Toast GUID when e_cv_voc_posref_txt is null,
      f.q_cv_voc_receipt_code_check_num_txt as order_number, -- This does not appear to match the actual order/check number from Toast
      ifnull(                                                                                            -- The order date can come from several locations depending on survey type:
        try_to_date(left(f.e_cv_voc_time_placed_date_time,10), ''YYYY-MM-DD''),                                     -- first try the actual order time from an Email Restaurant Survey
        ifnull(try_to_date(left(f.e_creation_date,4) || left(f.Q_CV_VOC_RECEIPT_CODE_DATETIME_TXT,4), ''YYYYMMDD''), -- then try the receipt date from a Receipt Restaurant Survey
          try_to_date(left(f.Q_COSTAVIDA_VOC_VISIT_DAY_DATE,10), ''YYYY-MM-DD'')                                    -- then try the visit date from a Contact Restaurant Survey
        ) 
      ) as order_date,
      ft.feedback_type_key as feedback_type_key,
      r.restaurant_key as restaurant_key,
      rd.date_key as response_date_key,
      od.date_key as order_date_key,
      ot.time_key as order_time_key
    from 
      identifier(:flat_table) f
      left join public.dim_feedback_type ft on ft.feedback_source_category_id=f.e_cv_feedback_program_enum 
        and ft.feedback_source_subcategory_id = f.e_cv_survey_type_enum 
        and ft.feedback_source_item_id = f.feedback_item
        and (ft.feedback_source_item_option_id = f.feedback_selection or f.is_comment)
      left join public.dim_restaurant r on r.restaurant_number=right(f.e_unitid ,4) and r.record_is_current and r.status=''Active''
      left join public.dim_date od on od.date=order_date and od.record_is_current
      left join public.dim_time ot on equal_null(ot.hour,
        case
          when substr(f.e_cv_voc_time_placed_date_time, 12, 2)::number between 0 and 23 then substr(f.e_cv_voc_time_placed_date_time, 12, 2)::number
          when substr(f.q_cv_voc_receipt_code_datetime_txt,5,2)::number between 0 and 23 then substr(f.q_cv_voc_receipt_code_datetime_txt,5,2)::number
          else null
        end
      )
      left join public.dim_date rd on rd.date=convert_timezone(''America/Denver'', f.e_response_date::timestamp_ltz)::date
    ;
    RETURN true;
  END
';
