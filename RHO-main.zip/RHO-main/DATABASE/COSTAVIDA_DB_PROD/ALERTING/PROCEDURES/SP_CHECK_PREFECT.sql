-- PROCEDURES: SP_CHECK_PREFECT
-- Generated on: 2025-06-05 11:43:30
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE PROCEDURE "SP_CHECK_PREFECT"()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    result BOOLEAN DEFAULT FALSE;
    email_subject STRING;
    email_body STRING;
BEGIN
    -- Replace this with your actual query that should return TRUE/FALSE
    -- Example: Check if there are any failed jobs in the last hour
    --SELECT TRUE INTO result;

    SELECT
      CASE
        WHEN STARTED <= DATEADD(HOUR, -2, CURRENT_TIMESTAMP()) THEN TRUE
        ELSE FALSE
      END AS SEND_ALERT INTO result
    FROM
      RAW.V_PREFECT_FLOW_RUN
    WHERE
      STARTED IS NOT NULL
    ORDER BY
      STARTED DESC
    LIMIT
      1;
    
    -- If condition is TRUE, send email
    IF (result = TRUE) THEN
        email_subject := ''SNOWFLAKE ALERT: Prefect Flows Not Running'';
        email_body := ''Prefect Flows are not executing.  Check Prefect Deployments at: https://app.prefect.cloud/account/16382767-199a-4f5b-b2b6-c1c404fd1ffa/workspace/273d433f-ba69-47b3-8c4e-8880aabbb3e9/deployments

The following query intiated this alert:

SELECT
  CASE
    WHEN STARTED <= DATEADD(HOUR, -2, CURRENT_TIMESTAMP()) THEN TRUE
    ELSE FALSE
  END AS SEND_ALERT
FROM
  RAW.V_PREFECT_FLOW_RUN
WHERE
  STARTED IS NOT NULL
ORDER BY
  STARTED DESC
LIMIT
  1;       
        '';
        
        -- Send email using Snowflake''s EMAIL notification
        CALL SYSTEM$SEND_EMAIL(
            ''AUTOMATED_ALERTING'',  
            ''mark.callison@solutions-ii.com'', 
            --''dataops@convx.com'', 
            :email_subject,
            :email_body
        );
        
        RETURN ''Email sent - condition was TRUE'';
    ELSE
        RETURN ''No email sent - condition was FALSE'';
    END IF;
END;
';
