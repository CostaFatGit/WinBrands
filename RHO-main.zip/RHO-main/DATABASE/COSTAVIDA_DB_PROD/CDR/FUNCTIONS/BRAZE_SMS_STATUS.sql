-- FUNCTIONS: BRAZE_SMS_STATUS
-- Generated on: 2025-06-05 11:43:28
-- Database: COSTAVIDA_DB_PROD

CREATE OR REPLACE FUNCTION "BRAZE_SMS_STATUS"("SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
   SELECT 
        case 
            when country is null then ''unsubscribed'' 
            when country is not null and sms_status = ''opted_in'' then ''subscribed''
            when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
            else ''unsubscribed''
        end as status
';
