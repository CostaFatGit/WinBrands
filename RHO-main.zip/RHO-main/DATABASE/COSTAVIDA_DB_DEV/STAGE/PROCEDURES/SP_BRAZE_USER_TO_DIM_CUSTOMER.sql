-- PROCEDURES: SP_BRAZE_USER_TO_DIM_CUSTOMER
-- Generated on: 2025-06-05 11:29:33
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_BRAZE_USER_TO_DIM_CUSTOMER"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

    --Put data into a temp table to empty the stream and in case we need to access it more than once
    CREATE OR REPLACE TEMPORARY TABLE 
      temp_STAGE_BRAZE_USER_DATA_STREAM
    AS
    SELECT
      *
    FROM
      STAGE.BRAZE_USER_DATA_STREAM;

    --Update DIM_CUSTOMER

    MERGE INTO 
        PUBLIC.DIM_CUSTOMER C
    USING 
    (
        SELECT
            DT.EXTERNAL_ID,
            DT.CURRENT_POINTS,
            DT.HISTORICAL_POINTS,
            DT.BRAZE_ID,
            DT.SPARKFLY_ID,
            DT.FAVORITE_RESTAURANT_NUMBER
        FROM 
        (
            SELECT
                S.EXTERNAL_ID,
                S.CURRENT_POINTS,
                S.HISTORICAL_POINTS,
                S.BRAZE_ID,
                S.SPARKFLY_ID,
                S.FAVORITE_RESTAURANT_NUMBER,
                ROW_NUMBER() OVER(PARTITION BY S.EXTERNAL_ID ORDER BY S.FILE_LAST_MODIFIED DESC) AS RN
            FROM
                temp_STAGE_BRAZE_USER_DATA_STREAM S
            WHERE
                S.METADATA$ACTION = ''INSERT''
                AND S.EXTERNAL_ID IS NOT NULL
        ) DT
        WHERE 
            DT.RN = 1
    ) SB ON SB.EXTERNAL_ID = C.SPENDGO_GUEST_ID
    WHEN 
        MATCHED 
        AND 
        (
            IFNULL(C.CURRENT_POINTS, 0) <> IFNULL(SB.CURRENT_POINTS, 0)
            OR IFNULL(C.HISTORICAL_POINTS, 0) <> IFNULL(SB.HISTORICAL_POINTS, 0)
            OR IFNULL(C.BRAZE_ID, ''0'') <> IFNULL(SB.BRAZE_ID, ''0'')
            --Don''t update.  Coming from SPENDGO ONLY as of 3/19/2025
            --OR IFNULL(C.FAVORITE_RESTAURANT_NUMBER, ''0'') <> IFNULL(SB.FAVORITE_RESTAURANT_NUMBER, ''0'')
            OR IFNULL(C.SPARKFLY_ID, ''0'') <> IFNULL(SB.SPARKFLY_ID, ''0'')
        ) 
    THEN
        UPDATE SET
            C.CURRENT_POINTS = SB.CURRENT_POINTS,
            C.HISTORICAL_POINTS = SB.HISTORICAL_POINTS,
            C.BRAZE_ID = SB.BRAZE_ID,
            --Don''t update.  Coming from SPENDGO ONLY as of 3/19/2025
            --C.FAVORITE_RESTAURANT_NUMBER = SB.FAVORITE_RESTAURANT_NUMBER,
            C.SPARKFLY_ID = SB.SPARKFLY_ID;

END';
