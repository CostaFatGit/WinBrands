-- PROCEDURES: SP_TOAST_ORDER_TO_FACT_PAYMENT
-- Generated on: 2025-06-05 11:29:45
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_TOAST_ORDER_TO_FACT_PAYMENT"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

    MERGE INTO PUBLIC.FACT_PAYMENT AS target
    USING (
        SELECT DISTINCT
          F.DIM_CARD_FINGERPRINT_KEY
         ,D.DATE_KEY
         ,T.TIME_KEY
         ,DT.POS_ORDER_ID
         ,DT.POS_CHECK_ID
         ,DT.PAYMENT_GUID
         ,DT.TENDER_GUID
         ,DT.PAYMENT_TYPE
         ,DT.CARD_TYPE
         ,DT.PAYMENT_STATUS
         ,DT.PAYMENT_METHOD_ID
         ,DT.CARD_ENTRY_MODE
         ,DT.CARD_PROCESSOR_TYPE
         ,DT.EXTERNAL_ID
         ,DT.IS_PROCESSED_OFFLINE
         ,DT.REFUND_STATUS
         ,DT.FIRST_NAME
         ,DT.LAST_NAME
         ,DT.LAST_FOUR
         ,DT.AMOUNT
         ,DT.AMOUNT_TENDERED
         ,DT.TIP
         ,DT.SURCHARGE
         ,DT.ORIGINAL_PROCESSING_FEE
         ,DT.MCA_REPAYMENT_AMOUNT
         ,DT.PAID_DATE_TIME
         ,DT.BUSINESS_DATE
         ,DT.CREATED_DATETIME
        FROM
        (
            SELECT
               p.value:orderGuid::STRING as POS_ORDER_ID,
               p.value:checkGuid::STRING as POS_CHECK_ID,
               p.value:guid::STRING as PAYMENT_GUID,
               p.value:tenderTransactionGuid::STRING as TENDER_GUID,
               p.value:type::STRING as PAYMENT_TYPE,
               p.value:cardType::STRING as CARD_TYPE,
               p.value:paymentStatus::STRING as PAYMENT_STATUS,
               p.value:paymentMethodId::STRING as PAYMENT_METHOD_ID,
               p.value:cardEntryMode::STRING as CARD_ENTRY_MODE,
               p.value:cardProcessorType::STRING as CARD_PROCESSOR_TYPE,
               p.value:externalId::STRING as EXTERNAL_ID,
               p.value:isProcessedOffline::BOOLEAN as IS_PROCESSED_OFFLINE,
               p.value:refundStatus::STRING as REFUND_STATUS,
               p.value:cardHolderFirstName::STRING as FIRST_NAME,
               p.value:cardHolderLastName::STRING as LAST_NAME,
               p.value:last4Digits::STRING as LAST_FOUR,
               p.value:amount::NUMBER(38,2) as AMOUNT,
               p.value:amountTendered::NUMBER(38,2) as AMOUNT_TENDERED,
               p.value:tipAmount::NUMBER(38,2) as TIP,
               p.value:surchargeAmount::NUMBER(38,2) as SURCHARGE,
               p.value:originalProcessingFee::NUMBER(38,2) as ORIGINAL_PROCESSING_FEE,
               p.value:mcaRepaymentAmount::NUMBER(38,2) as MCA_REPAYMENT_AMOUNT,
               TO_TIMESTAMP_LTZ(REPLACE(p.value:paidDate::STRING, ''T'', '' '')) as PAID_DATE_TIME,
               p.value:paidBusinessDate::STRING as BUSINESS_DATE,
               CURRENT_TIMESTAMP() as CREATED_DATETIME,
               TO_DATE(TO_TIMESTAMP_LTZ(REPLACE(p.value:paidDate::STRING, ''T'', '' ''))) AS "DATE",
               DATE_PART(HOUR, TO_TIMESTAMP_LTZ(REPLACE(p.value:paidDate::STRING, ''T'', '' ''))) AS "HOUR"
            FROM 
              STAGE.TOAST_ORDER T,
            LATERAL FLATTEN(input => T.CHECKS) c,
            LATERAL FLATTEN(input => c.value:payments) p
            WHERE
              T.STAGE_PROCESSED_DATETIME IS NULL
        ) DT
        JOIN
          PUBLIC.DIM_DATE D ON DT.DATE = D.DATE
        JOIN
          PUBLIC.DIM_TIME T ON DT.HOUR = T.HOUR
        LEFT JOIN
        (
            SELECT DISTINCT
              CF.DIM_CARD_FINGERPRINT_KEY
             ,F.PAYMENT_GUID
            FROM
              RAW.TOAST_FINGERPRINT F
            JOIN
              PUBLIC.DIM_CARD_FINGERPRINT CF ON F.CARD_FINGERPRINT = CF.CARD_FINGERPRINT_GUID
        ) F ON DT.PAYMENT_GUID = F.PAYMENT_GUID
    ) AS source
    ON (
        IFNULL(target.DIM_CARD_FINGERPRINT_KEY, ''-1'') = IFNULL(source.DIM_CARD_FINGERPRINT_KEY, ''-1'')
        AND target.DATE_KEY = source.DATE_KEY
        AND target.TIME_KEY = source.TIME_KEY
        AND target.POS_ORDER_ID = source.POS_ORDER_ID
        AND target.POS_CHECK_ID = source.POS_CHECK_ID
        AND target.PAYMENT_GUID = source.PAYMENT_GUID
        AND IFNULL(target.TENDER_GUID, ''-1'') = IFNULL(source.TENDER_GUID, ''-1'')
        AND IFNULL(target.PAYMENT_TYPE, ''-1'') = IFNULL(source.PAYMENT_TYPE, ''-1'')
        AND IFNULL(target.CARD_TYPE, ''-1'') = IFNULL(source.CARD_TYPE, ''-1'')
        AND IFNULL(target.PAYMENT_STATUS, ''-1'') = IFNULL(source.PAYMENT_STATUS, ''-1'')
        AND IFNULL(target.PAYMENT_METHOD_ID, ''-1'') = IFNULL(source.PAYMENT_METHOD_ID, ''-1'')
        AND IFNULL(target.CARD_ENTRY_MODE, ''-1'') = IFNULL(source.CARD_ENTRY_MODE, ''-1'')
        AND IFNULL(target.CARD_PROCESSOR_TYPE, ''-1'') = IFNULL(source.CARD_PROCESSOR_TYPE, ''-1'')
        AND IFNULL(target.EXTERNAL_ID, ''-1'') = IFNULL(source.EXTERNAL_ID, ''-1'')
        --AND IFNULL(target.IS_PROCESSED_OFFLINE, FALSE) = IFNULL(source.IS_PROCESSED_OFFLINE, FALSE)
        AND IFNULL(target.REFUND_STATUS, ''-1'') = IFNULL(source.REFUND_STATUS, ''-1'')
        AND IFNULL(target.FIRST_NAME, ''-1'') = IFNULL(source.FIRST_NAME, ''-1'')
        AND IFNULL(target.LAST_NAME, ''-1'') = IFNULL(source.LAST_NAME, ''-1'')
        AND IFNULL(target.LAST_FOUR, ''-1'') = IFNULL(source.LAST_FOUR, ''-1'')
        AND IFNULL(target.AMOUNT, -1) = IFNULL(source.AMOUNT, -1)
        AND IFNULL(target.AMOUNT_TENDERED, -1) = IFNULL(source.AMOUNT_TENDERED, -1)
        AND IFNULL(target.TIP, -1) = IFNULL(source.TIP, -1)
        AND IFNULL(target.SURCHARGE, -1) = IFNULL(source.SURCHARGE, -1)
        AND IFNULL(target.ORIGINAL_PROCESSING_FEE, -1) = IFNULL(source.ORIGINAL_PROCESSING_FEE, -1)
        AND IFNULL(target.MCA_REPAYMENT_AMOUNT, -1) = IFNULL(source.MCA_REPAYMENT_AMOUNT, -1)
        AND IFNULL(target.PAID_DATE_TIME, ''1900-01-01'') = IFNULL(source.PAID_DATE_TIME, ''1900-01-01'')
        AND IFNULL(target.BUSINESS_DATE, ''-1'') = IFNULL(source.BUSINESS_DATE, ''-1'')
    )
    WHEN NOT MATCHED THEN 
        INSERT (
            DIM_CARD_FINGERPRINT_KEY,
            DATE_KEY,
            TIME_KEY,
            POS_ORDER_ID,
            POS_CHECK_ID,
            PAYMENT_GUID,
            TENDER_GUID,
            PAYMENT_TYPE,
            CARD_TYPE,
            PAYMENT_STATUS,
            PAYMENT_METHOD_ID,
            CARD_ENTRY_MODE,
            CARD_PROCESSOR_TYPE,
            EXTERNAL_ID,
            IS_PROCESSED_OFFLINE,
            REFUND_STATUS,
            FIRST_NAME,
            LAST_NAME,
            LAST_FOUR,
            AMOUNT,
            AMOUNT_TENDERED,
            TIP,
            SURCHARGE,
            ORIGINAL_PROCESSING_FEE,
            MCA_REPAYMENT_AMOUNT,
            PAID_DATE_TIME,
            BUSINESS_DATE,
            CREATED_DATETIME
        )
        VALUES (
            source.DIM_CARD_FINGERPRINT_KEY,
            source.DATE_KEY,
            source.TIME_KEY,
            source.POS_ORDER_ID,
            source.POS_CHECK_ID,
            source.PAYMENT_GUID,
            source.TENDER_GUID,
            source.PAYMENT_TYPE,
            source.CARD_TYPE,
            source.PAYMENT_STATUS,
            source.PAYMENT_METHOD_ID,
            source.CARD_ENTRY_MODE,
            source.CARD_PROCESSOR_TYPE,
            source.EXTERNAL_ID,
            source.IS_PROCESSED_OFFLINE,
            source.REFUND_STATUS,
            source.FIRST_NAME,
            source.LAST_NAME,
            source.LAST_FOUR,
            source.AMOUNT,
            source.AMOUNT_TENDERED,
            source.TIP,
            source.SURCHARGE,
            source.ORIGINAL_PROCESSING_FEE,
            source.MCA_REPAYMENT_AMOUNT,
            source.PAID_DATE_TIME,
            source.BUSINESS_DATE,
            source.CREATED_DATETIME
        );
   
    RETURN ''Success'';
  
END';
