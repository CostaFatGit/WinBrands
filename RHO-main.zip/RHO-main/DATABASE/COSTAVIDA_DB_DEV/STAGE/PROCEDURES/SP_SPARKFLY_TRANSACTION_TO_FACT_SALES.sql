-- PROCEDURES: SP_SPARKFLY_TRANSACTION_TO_FACT_SALES
-- Generated on: 2025-06-05 11:29:41
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_SPARKFLY_TRANSACTION_TO_FACT_SALES"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

    --Clear the stream.  We are really only using it to let us know we need to run an update.
    --We then just run the update using the entire table to make sure we catch everything.
    --The stream was getting cleared and we were missing records before.
    CREATE OR REPLACE TEMPORARY TABLE TEMP_SPARKFLY_TRANSACTION_STREAM AS
        SELECT 
          * 
        FROM 
          STAGE.SPARKFLY_TRANSACTION_STREAM; 

    --Doing this for optimization.  Not doing MAX(RUN_ID) in case ther are failures.
    CREATE OR REPLACE TEMPORARY TABLE TEMP_TRANSACTIONS AS
        SELECT
          *
        FROM
          STAGE.SPARKFLY_TRANSACTION
        WHERE
          CREATED_DATE_TIME >= DATEADD(HOUR, -24, CURRENT_TIMESTAMP());

    UPDATE 
      PUBLIC.FACT_SALES FS
    SET 
      FS.CUSTOMER_KEY = C.CUSTOMER_KEY
    FROM 
    (
        SELECT DISTINCT
          DT.SPENDGO_GUEST_ID
         ,DT.POS_ORDER_ID
        FROM
        (
            SELECT
              S.MEMBER_ID_1 AS SPENDGO_GUEST_ID
             ,S.TRANSACTION_IDENTIFIER AS POS_ORDER_ID
            FROM 
              TEMP_TRANSACTIONS S
            JOIN 
              PUBLIC.DIM_CUSTOMER C ON S.MEMBER_ID_1 = C.SPENDGO_GUEST_ID
            
            UNION
            
            SELECT
              S.MEMBER_ID_2 AS SPENDGO_GUEST_ID
             ,S.TRANSACTION_IDENTIFIER AS POS_ORDER_ID
            FROM 
              TEMP_TRANSACTIONS S
            JOIN 
              PUBLIC.DIM_CUSTOMER C ON S.MEMBER_ID_2 = C.SPENDGO_GUEST_ID
            
            UNION
            
            SELECT
              S.MEMBER_ID_3 AS SPENDGO_GUEST_ID
             ,S.TRANSACTION_IDENTIFIER AS POS_ORDER_ID
            FROM 
              TEMP_TRANSACTIONS S
            JOIN 
              PUBLIC.DIM_CUSTOMER C ON S.MEMBER_ID_3 = C.SPENDGO_GUEST_ID
        ) DT
        WHERE 
          DT.POS_ORDER_ID IS NOT NULL
    ) DT2
    JOIN 
      PUBLIC.DIM_CUSTOMER C ON DT2.SPENDGO_GUEST_ID = C.SPENDGO_GUEST_ID
    WHERE 
      FS.POS_ORDER_ID = DT2.POS_ORDER_ID
      AND IFNULL(FS.CUSTOMER_KEY, 0) = 0;

END';
