-- PROCEDURES: SP_OLO_PAY_TRANSACTION_TO_FACT_SALES
-- Generated on: 2025-06-05 11:29:38
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_OLO_PAY_TRANSACTION_TO_FACT_SALES"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

    --The temp table greatly improved performance.  That is the only reason it is being used.
    CREATE OR REPLACE TEMPORARY TABLE Temp_Sales AS
        SELECT
          FS.SALES_KEY
         ,RC.CUSTOMER_KEY
        FROM
        (
          --DISTINCT keeps from getting dupes if a full refresh is ran
          SELECT DISTINCT
            S.POS_REFERENCE_ID
           ,S.CUSTOMER_EMAIL
          FROM
            STAGE.OLO_PAY_TRANSACTION S
          WHERE
            S.STAGE_PROCESSED_DATETIME IS NULL
        ) O
        JOIN
        (
          --Email can''t be trusted to be unique.  Choose the first Customer to have it.
          SELECT
            MIN(R.CUSTOMER_KEY) AS CUSTOMER_KEY
           ,R.EMAIL
          FROM
            RESTRICTED.DIM_CUSTOMER_PII R
          GROUP BY
            R.EMAIL
        ) RC ON O.CUSTOMER_EMAIL = RC.EMAIL
        JOIN
          PUBLIC.FACT_SALES FS ON O.POS_REFERENCE_ID = FS.POS_ORDER_ID
        WHERE
          FS.CUSTOMER_KEY = 0;
    
    MERGE INTO 
      PUBLIC.FACT_SALES FS
    USING 
      Temp_Sales TS
    ON 
      FS.SALES_KEY = TS.SALES_KEY
    WHEN MATCHED THEN 
      UPDATE SET
        FS.CUSTOMER_KEY = TS.CUSTOMER_KEY;

END';
