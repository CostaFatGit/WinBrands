-- PROCEDURES: SP_TOAST_DINING_OPTION_RAW_TO_STAGE
-- Generated on: 2025-06-05 11:29:42
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_TOAST_DINING_OPTION_RAW_TO_STAGE"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
    -- Start a new transaction
    BEGIN TRANSACTION;
    
    TRUNCATE TABLE
      STAGE.TOAST_DINING_OPTION;

    --Get the records that share the most recent created datetime to indicate they came from the most recent run.
    --The get the most recent GUID record from those.  This should be unneccessary because it SHOULD only 
    --return one record per GUID, but this is an easy failsafe.
    --If you don''t do the MOST_RECENT_RUN derived table JOIN, then the QUALIFY ROW_NUMBER part will get records that exist
    --across multiple runs.  We ONLY want to move the most current run from RAW to STAGE.
    INSERT INTO 
      STAGE.TOAST_DINING_OPTION(GUID, ENTITY_TYPE, EXTERNAL_ID, NAME, BEHAVIOR, CURBSIDE, CREATED_DATETIME)
    SELECT 
      T.GUID
     ,T.ENTITY_TYPE
     ,T.EXTERNAL_ID
     ,T.NAME
     ,T.BEHAVIOR
     ,T.CURBSIDE
     ,T.CREATED_DATETIME
    FROM
      LOAD.RAW_TOAST_DINING_OPTION T
    JOIN
    (
        SELECT
          MAX(CREATED_DATETIME) AS MOST_RECENT_RUN
        FROM
          LOAD.RAW_TOAST_DINING_OPTION
    ) DT ON T.CREATED_DATETIME = DT.MOST_RECENT_RUN
    QUALIFY 
      ROW_NUMBER() OVER (PARTITION BY T.GUID ORDER BY T.CREATED_DATETIME DESC) = 1;
    
    -- If we get here, commit the transaction
    COMMIT;
    
    RETURN ''Successfully inserted '' || SQLROWCOUNT || '' dining options'';
EXCEPTION
    WHEN OTHER THEN
        -- Roll back all changes if any error occurs
        ROLLBACK;
        RETURN ''Error: '' || SQLERRM;
END';
