-- PROCEDURES: SP_BRAZE_USER_RAW_TO_STAGE
-- Generated on: 2025-06-05 11:29:33
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_BRAZE_USER_RAW_TO_STAGE"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN

    --Put data into a temp table to empty the stream and in case we need to access it more than once
    CREATE OR REPLACE TEMPORARY TABLE 
      temp_RAW_BRAZE_USER_DATA_STREAM
    AS
    SELECT
      *
    FROM
      LOAD.RAW_BRAZE_USER_DATA_STREAM;

    INSERT INTO STAGE.BRAZE_USER_DATA 
    (
      RUN_ID
     ,BRAZE_ID
     ,EXTERNAL_ID
     ,FIRST_NAME
     ,LAST_NAME
     ,DOB
     ,COUNTRY
     ,EMAIL
     ,PHONE
     ,TOTAL_REVENUE
     ,CUSTOM_ATTRIBUTES
     ,CUSTOM_EVENTS
     ,FILE_NAME
     ,FILE_LAST_MODIFIED
     ,CREATED_DATE_TIME
     ,HISTORICAL_POINTS
     ,CURRENT_POINTS
     ,FAVORITE_RESTAURANT_NUMBER
     ,SPARKFLY_ID
    )
    SELECT
      RUN_ID
     ,JSON_DATA:braze_id::STRING AS BRAZE_ID
     ,JSON_DATA:external_id::STRING AS EXTERNAL_ID
     ,JSON_DATA:first_name::STRING AS FIRST_NAME
     ,JSON_DATA:last_name::STRING AS LAST_NAME
     ,JSON_DATA:dob::DATE AS DOB
     ,JSON_DATA:country::STRING AS COUNTRY
     ,JSON_DATA:email::STRING AS EMAIL
     ,JSON_DATA:phone::STRING AS PHONE
     ,JSON_DATA:total_revenue::NUMBER AS TOTAL_REVENUE
     ,JSON_DATA:custom_attributes AS CUSTOM_ATTRIBUTES
     ,JSON_DATA:custom_events AS CUSTOM_EVENTS
     ,FILE_NAME
     ,FILE_LAST_MODIFIED
     ,CREATED_DATE_TIME
     ,JSON_DATA:"custom_attributes"."historical_points" AS HISTORICAL_POINTS
     ,JSON_DATA:"custom_attributes"."Current_Point_Balance" AS CURRENT_POINTS
     ,REPLACE(JSON_DATA:"custom_attributes"."favorite_location", ''"'', '''') AS FAVORITE_RESTAURANT_NUMBER
     ,REPLACE(JSON_DATA:"custom_attributes"."Sparkfly_Member_ID", ''"'', '''') AS SPARKFLY_ID
    FROM 
      temp_RAW_BRAZE_USER_DATA_STREAM;

END
';
