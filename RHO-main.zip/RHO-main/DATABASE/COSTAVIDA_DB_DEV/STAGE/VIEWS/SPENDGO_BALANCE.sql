-- VIEWS: SPENDGO_BALANCE
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_BALANCE(
	SPENDGO_ID,
	CURRENT_REWARDS_BALANCE,
	CURRENT_POINTS_BALANCE
) as 
select 
    spendgo_id, 
    current_rewards_balance, 
    current_points_balance
from COSTAVIDA_DB_PROD.RESTRICTED.CUSTOMER_LIST_W_POINTS --462135
qualify row_number() over (partition by spendgo_id order by spendgo_id desc) = 1;
