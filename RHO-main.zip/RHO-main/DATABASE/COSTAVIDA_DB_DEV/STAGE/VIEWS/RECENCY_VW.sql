-- VIEWS: RECENCY_VW
-- Generated on: 2025-06-05 11:29:29
-- Database: COSTAVIDA_DB_DEV

create or replace view RECENCY_VW(
	SPENDGO_GUEST_ID,
	MOST_RECENT_VISIT,
	DATE_DIFF,
	RECENCY
) as 
    with rec as (
        Select
            SPENDGO_GUEST_ID,
            Max(Date) Most_Recent_Visit
        From 
            COSTAVIDA_DB_PROD.PUBLIC.ORDER_SUMMARY   
        Where
            1=1
        And SPENDGO_GUEST_ID not ilike 'unknown'
        Group by
            SPENDGO_GUEST_ID
        Order by
            Most_Recent_Visit Desc
        )
Select
  SPENDGO_GUEST_ID,
  Most_Recent_Visit,
  DateDiff(Days,Most_Recent_Visit,current_date) AS Date_Diff,
  Case  
    WHEN Date_Diff IS NULL             THEN 'No_Recent_Visit'
    When Date_Diff between   0 and 30  THEN '0-30'
    When Date_Diff between  31 and 60  THEN '31-60'
    When Date_Diff between  61 and 90  THEN '61-90'
    When Date_Diff between  91 and 120 THEN '91-120'
    When Date_Diff between 121 and 150 THEN '121-150'
    When Date_Diff between 151 and 180 THEN '151-180'
    When Date_Diff >= 181              THEN '181+'
    Else '180+'
   End as Recency
From
  rec
;
