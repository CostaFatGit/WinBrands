-- VIEWS: SPENDGO_EMAIL_CLEANUP_1
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_EMAIL_CLEANUP_1(
	SPENDGO_GUEST_ID,
	FIRST_NAME,
	LAST_NAME,
	EMAIL,
	SMS_PREFERENCE,
	EMAIL_PREFERENCE,
	FILELASTMODIFIED,
	SPENDGO_GUEST_ID_DC,
	IN_MARKETING_EMAIL,
	IN_MARKETING_PUSH,
	CUSTOMER_KEY,
	FN_RESTRICTED,
	LN_RESTRICTED,
	EMAIL_RESTRICTED
) as
Select
  rp.Spendgo_Guest_Id
  ,rp.First_Name
  ,rp.Last_name
  ,rp.email
  ,rp.SMS_Preference
  ,rp.email_Preference
  ,rp.FILELASTMODIFIED
  ,dc.Spendgo_Guest_Id as Spendgo_Guest_Id_DC
  ,dc.In_Marketing_Email
  ,dc.IN_MARKETING_PUSH
  ,rs.Customer_Key
  ,rs.First_Name as FN_restricted
  ,rs.Last_Name as LN_restricted
  ,rs.email as email_restricted
  From  COSTAVIDA_DB_PROD.STAGE.SPENDGO_MEMBER_CURRENT_VW rp
  Inner join COSTAVIDA_DB_PROD.PUBLIC.DIM_CUSTOMER dc on rp.spendgo_guest_id=dc.spendgo_guest_id
  Inner Join COSTAVIDA_DB_PROD.RESTRICTED.DIM_CUSTOMER_PII rs on dc.CUSTOMER_KEY=rs.customer_key
  Where
    1=1
    And rp.email_Preference='FALSE'
    And dc.in_marketing_email=TRUE
UNION
Select
  rp.Spendgo_Guest_Id
  ,rp.First_Name
  ,rp.Last_name
  ,rp.email
  ,rp.SMS_Preference
  ,rp.email_Preference
  ,rp.FILELASTMODIFIED
  ,dc.Spendgo_Guest_Id as Spendgo_Guest_Id_DC
  ,dc.In_Marketing_Email
  ,dc.IN_MARKETING_PUSH
  ,rs.Customer_Key
  ,rs.First_Name as FN_restricted
  ,rs.Last_Name as LN_restricted
  ,rs.email as email_restricted
  From  COSTAVIDA_DB_PROD.STAGE.SPENDGO_MEMBER_CURRENT_VW rp
  Inner join COSTAVIDA_DB_PROD.PUBLIC.DIM_CUSTOMER dc on rp.spendgo_guest_id=dc.spendgo_guest_id
  Inner Join COSTAVIDA_DB_PROD.RESTRICTED.DIM_CUSTOMER_PII rs on dc.CUSTOMER_KEY=rs.customer_key
  join (
        select
            distinct 
            external_user_id
         from braze_shared.datalake_sharing.users_messages_email_unsubscribe_shared
  ) bu on (rp.spendgo_guest_id = bu.external_user_id)
  Where
    1=1
    and lower(rp.email_Preference) = 'true' 
Order by
   spendgo_guest_id
;
