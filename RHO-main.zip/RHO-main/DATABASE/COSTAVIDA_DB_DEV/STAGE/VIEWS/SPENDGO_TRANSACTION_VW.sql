-- VIEWS: SPENDGO_TRANSACTION_VW
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_TRANSACTION_VW(
	EVENT_ID,
	SPENDGO_GUEST_ID,
	PHONE,
	EMAIL,
	STORE_NUMBER,
	STORE_NAME,
	EVENT_TYPE,
	EVENT_LOCAL_TIME,
	EVENT_UTC_TIME,
	EVENT_TOTAL,
	FILE_LAST_MODIFIED,
	FILE_NAME
) as 
select *
  from COSTAVIDA_DB_PROD.LOAD.RAW_SPENDGO_TRANSACTION
where 1=1 
qualify row_number() over (partition by event_id, spendgo_guest_id, event_type, event_local_time order by file_last_modified desc) = 1;
