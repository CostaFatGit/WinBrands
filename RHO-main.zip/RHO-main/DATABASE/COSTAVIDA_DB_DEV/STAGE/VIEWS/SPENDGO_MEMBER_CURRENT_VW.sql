-- VIEWS: SPENDGO_MEMBER_CURRENT_VW
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_MEMBER_CURRENT_VW(
	PHONE,
	EMAIL,
	SPENDGO_GUEST_ID,
	LOYALTY_STATUS,
	JOIN_TIME,
	UTC_JOIN_TIME,
	FIRST_NAME,
	LAST_NAME,
	BIRTHDATE,
	GENDER,
	FAVORITE_STORE_NUMBER,
	FAVORITE_STORE_NAME,
	SMS_PREFERENCE,
	EMAIL_PREFERENCE,
	INPUT_SOURCE,
	STREET,
	CITY,
	STATE,
	POSTAL_CODE,
	COUNTRY,
	IS_DELETED,
	FILELASTMODIFIED,
	FILE_NAME,
	OFFERS_USED,
	REGISTERED,
	POS_ORDER_COUNT,
	CURRENT_POINTS_BALANCE,
	CURRENT_REWARDS_BALANCE
) as 
select 
    aa.*,
    coalesce(bb.offers_used,0) as offers_used,
    case 
        when loyalty_status = 'starter' and coalesce(dd.current_points_balance,0) = 0 then false 
        when loyalty_status = 'starter' and coalesce(dd.current_points_balance,0) > 0 then true
        else true 
    end as registered,
    coalesce(cc.order_count,0) as pos_order_count,
    coalesce(dd.current_points_balance,0) as current_points_balance,
    coalesce(dd.current_rewards_balance,0) as current_rewards_balance
from COSTAVIDA_DB_PROD.LOAD.RAW_SPENDGO_MEMBER aa
left join COSTAVIDA_DB_PROD.STAGE.SPENDGO_OFFERS_USED bb on (aa.spendgo_guest_id = bb.spendgo_guest_id)
left join COSTAVIDA_DB_PROD.STAGE.SPENDGO_USER_POS_TRANSACTION_COUNT cc on (aa.spendgo_guest_id = cc.spendgo_guest_id)
left join costavida_db_prod.stage.spendgo_balance dd on (aa.spendgo_guest_id = dd.spendgo_id)
qualify row_number() over (partition by aa.spendgo_guest_id order by aa.filelastmodified desc) = 1;
