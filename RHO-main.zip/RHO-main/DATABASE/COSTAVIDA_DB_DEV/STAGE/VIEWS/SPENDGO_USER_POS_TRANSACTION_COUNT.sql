-- VIEWS: SPENDGO_USER_POS_TRANSACTION_COUNT
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_USER_POS_TRANSACTION_COUNT(
	SPENDGO_GUEST_ID,
	ORDER_COUNT
) as 
select 
    bb.spendgo_guest_id,
    count(distinct pos_order_id) as order_count,
  from COSTAVIDA_DB_PROD.PUBLIC.FACT_SALES aa 
  join COSTAVIDA_DB_PROD.PUBLIC.DIM_CUSTOMER bb on (aa.customer_key = bb.customer_key)
where bb.spendgo_guest_id <> 'UNKNOWN'
group by 
    bb.spendgo_guest_id;
