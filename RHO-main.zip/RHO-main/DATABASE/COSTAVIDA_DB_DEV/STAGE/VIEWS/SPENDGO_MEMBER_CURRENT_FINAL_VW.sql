-- VIEWS: SPENDGO_MEMBER_CURRENT_FINAL_VW
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_MEMBER_CURRENT_FINAL_VW(
	PHONE,
	EMAIL,
	SPENDGO_GUEST_ID,
	LOYALTY_STATUS,
	JOIN_TIME,
	UTC_JOIN_TIME,
	FIRST_NAME,
	LAST_NAME,
	BIRTHDATE,
	GENDER,
	FAVORITE_STORE_NUMBER,
	FAVORITE_STORE_NAME,
	SMS_PREFERENCE,
	EMAIL_PREFERENCE,
	INPUT_SOURCE,
	STREET,
	CITY,
	STATE,
	POSTAL_CODE,
	COUNTRY,
	IS_DELETED,
	FILELASTMODIFIED,
	FILE_NAME,
	OFFERS_USED,
	REGISTERED,
	POS_ORDER_COUNT,
	CURRENT_POINTS_BALANCE,
	CURRENT_REWARDS_BALANCE
) as 
select 
    aa.phone_number as PHONE,
    bb.EMAIL,
    aa.spendgo_id as SPENDGO_GUEST_ID,
    aa.LOYALTY_STATUS,
    bb.JOIN_TIME,
    bb.UTC_JOIN_TIME,
    aa.FIRST_NAME,
    aa.LAST_NAME,
    bb.BIRTHDATE,
    bb.GENDER,
    bb.FAVORITE_STORE_NUMBER,
    bb.FAVORITE_STORE_NAME,
    bb.SMS_PREFERENCE,
    bb.EMAIL_PREFERENCE,
    bb.INPUT_SOURCE,
    bb.STREET,
    bb.CITY,
    bb.STATE,
    bb.POSTAL_CODE,
    bb.COUNTRY,
    bb.IS_DELETED,
    bb.FILELASTMODIFIED,
    bb.FILE_NAME,
    coalesce(cc.offers_used,0) as offers_used,
    case 
        when aa.loyalty_status = 'starter' and coalesce(ee.current_points_balance,0) = 0 then false 
        when aa.loyalty_status = 'starter' and coalesce(ee.current_points_balance,0) > 0 then true
        else true 
    end as registered,
    coalesce(dd.order_count,0) as pos_order_count,
    coalesce(ee.current_points_balance,0) as current_points_balance,
    coalesce(ee.current_rewards_balance,0) as current_rewards_balance
from (
    select * 
      from COSTAVIDA_DB_PROD.LOAD.RAW_SPENDGO_MEMBER_FINAL
   qualify row_number() over (partition by spendgo_id order by spendgo_join_date_utc desc) = 1
   ) aa 
left join (
    select * 
      from COSTAVIDA_DB_PROD.LOAD.RAW_SPENDGO_MEMBER
   qualify row_number() over (partition by spendgo_guest_id order by filelastmodified desc) = 1
   ) bb on (aa.spendgo_id = bb.spendgo_guest_id)
left join COSTAVIDA_DB_PROD.STAGE.SPENDGO_OFFERS_USED cc on (aa.spendgo_id = cc.spendgo_guest_id)
left join COSTAVIDA_DB_PROD.STAGE.SPENDGO_USER_POS_TRANSACTION_COUNT dd on (aa.spendgo_id = dd.spendgo_guest_id)
left join costavida_db_prod.stage.spendgo_balance ee on (aa.spendgo_id = ee.spendgo_id)
order by aa.spendgo_id;
