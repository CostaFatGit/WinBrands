-- VIEWS: SPENDGO_OFFERS_USED
-- Generated on: 2025-06-05 11:29:30
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_OFFERS_USED(
	SPENDGO_GUEST_ID,
	OFFERS_USED
) as 
select 
    spendgo_guest_id, 
    count(*) as offers_used 
  from COSTAVIDA_DB_PROD.STAGE.SPENDGO_TRANSACTION_VW
 where event_type = 'offer used'
group by spendgo_guest_id;
