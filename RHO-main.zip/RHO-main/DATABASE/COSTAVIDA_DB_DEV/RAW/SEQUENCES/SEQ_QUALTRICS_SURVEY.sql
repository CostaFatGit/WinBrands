-- SEQUENCES: SEQ_QUALTRICS_SURVEY
-- Generated on: 2025-06-05 11:28:48
-- Database: COSTAVIDA_DB_DEV

create or replace sequence SEQ_QUALTRICS_SURVEY start with 1 increment by 1 order;
