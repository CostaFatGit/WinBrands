-- SEQUENCES: SEQ_TOAST_ORDER
-- Generated on: 2025-06-05 11:28:48
-- Database: COSTAVIDA_DB_DEV

create or replace sequence SEQ_TOAST_ORDER start with 1 increment by 1 order;
