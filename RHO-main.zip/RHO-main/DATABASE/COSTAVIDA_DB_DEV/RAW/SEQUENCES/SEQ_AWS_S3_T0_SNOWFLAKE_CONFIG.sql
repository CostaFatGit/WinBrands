-- SEQUENCES: SEQ_AWS_S3_T0_SNOWFLAKE_CONFIG
-- Generated on: 2025-06-05 11:28:47
-- Database: COSTAVIDA_DB_DEV

create or replace sequence SEQ_AWS_S3_T0_SNOWFLAKE_CONFIG start with 1 increment by 1 order;
