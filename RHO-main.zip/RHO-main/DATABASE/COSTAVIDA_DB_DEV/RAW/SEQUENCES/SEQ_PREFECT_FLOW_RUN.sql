-- SEQUENCES: SEQ_PREFECT_FLOW_RUN
-- Generated on: 2025-06-05 11:28:48
-- Database: COSTAVIDA_DB_DEV

create or replace sequence SEQ_PREFECT_FLOW_RUN start with 1 increment by 1 order;
