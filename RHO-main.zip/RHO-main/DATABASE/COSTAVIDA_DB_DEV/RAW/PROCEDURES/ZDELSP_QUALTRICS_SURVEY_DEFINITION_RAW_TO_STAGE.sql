-- PROCEDURES: ZDELSP_QUALTRICS_SURVEY_DEFINITION_RAW_TO_STAGE
-- Generated on: 2025-06-05 11:29:45
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "ZDELSP_QUALTRICS_SURVEY_DEFINITION_RAW_TO_STAGE"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
COMMENT='user-defined procedure'
EXECUTE AS OWNER
AS 'BEGIN

    BEGIN TRANSACTION;
    
    TRUNCATE TABLE
      STAGE.QUALTRICS_SURVEY_DEFINITION;

    INSERT INTO 
      STAGE.QUALTRICS_SURVEY_DEFINITION(RAW_QUALTRICS_SURVEY_DEFINITION_ID, RUN_ID, SURVEY_ID, SURVEY_DEFINITION, SURVEY_NAME, QUESTION_ID, QUESTION, QUESTION_TEXT, QUESTION_TYPE, ANSWER, ANSWER_TEXT, IS_COMMENT, RAW_CREATED_DATETIME, RAW_PROCESSED_DATETIME, STAGE_CREATED_DATETIME, STAGE_PROCESSED_DATETIME, QUESTION_ID_FORMATTED)
    SELECT
      R.RAW_QUALTRICS_SURVEY_DEFINITION_ID
     ,R.RUN_ID
     ,R.SURVEY_ID
     ,R.SURVEY_DEFINITION
     ,PARSE_JSON(SURVEY_DEFINITION):result:name::string AS SURVEY_NAME
     ,q.key::string AS QUESTION_ID
     ,q.value:"questionName"::string AS QUESTION
     ,q.value:"questionText"::string AS QUESTION_TEXT
     ,q.value:"questionType":"type"::string AS QUESTION_TYPE
     --,c.key::string AS ANSWER
     ,CASE
        WHEN q.value:"questionType":"type"::string = ''TE'' THEN ''cmt''
        ELSE c.key::string
      END AS ANSWER
     --,c.value:"choiceText"::string AS ANSWER_TEXT
     ,CASE
        WHEN q.value:"questionType":"type"::string = ''TE'' THEN ''Comment''
        ELSE c.value:"choiceText"::string
      END AS ANSWER_TEXT
     ,CASE
        WHEN q.value:"questionType":"type"::string = ''TE'' THEN TRUE
        ELSE FALSE
      END
     ,R.RAW_CREATED_DATETIME
     ,R.RAW_PROCESSED_DATETIME
     ,CURRENT_TIMESTAMP()
     ,NULL
     ,CASE
        WHEN c.key::string IS NOT NULL THEN CONCAT(q.key::string, ''_'', c.key::string)
        ELSE q.key::string
      END AS QUESTION_ID_FORMATTED
    FROM 
      RAW.QUALTRICS_SURVEY_DEFINITION R,
    LATERAL FLATTEN(input => PARSE_JSON(R.SURVEY_DEFINITION):result:questions) q,
    LATERAL FLATTEN(input => q.value:choices, outer => true) c
    WHERE
      R.RAW_PROCESSED_DATETIME IS NULL;

    -- If we get here, commit the transaction
    COMMIT;
    
    RETURN ''Success'';
    
EXCEPTION
    WHEN OTHER THEN
        -- Roll back all changes if any error occurs
        ROLLBACK;
        RETURN ''Error: '' || SQLERRM;
  
END';
