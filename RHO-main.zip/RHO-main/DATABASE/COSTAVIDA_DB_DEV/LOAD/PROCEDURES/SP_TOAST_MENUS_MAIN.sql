-- PROCEDURES: SP_TOAST_MENUS_MAIN
-- Generated on: 2025-06-05 11:29:44
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_TOAST_MENUS_MAIN"("RAW_NAME" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    flat_tbl VARCHAR default ''LOAD.FLAT_TOAST_MENU'';
    -- raw_tbl VARCHAR default ''LOAD.RAW_TOAST_MENUS_V2_MENUS'';
    -- raw_stream VARCHAR default ''LOAD.RAW_TOAST_MENUS_V2_MENUS_STREAM'';
    -- rs RESULTSET DEFAULT (select system$stream_has_data(:raw_stream) as stream_has_data);
    rs RESULTSET DEFAULT (SELECT COUNT(*) as menu_rows FROM IDENTIFIER(:raw_name));
    csr CURSOR FOR rs;
    menu_rows number;

BEGIN
    -- Check for an updated raw table before replacing the downstream table.
    -- This prevents a failed load from erasing the local menu data.
    FOR thisrow IN csr DO
        menu_rows := thisrow.menu_rows;
    END FOR;

    IF (menu_rows > 0) THEN
        -- There are new records in the stream to process
       
        -- Data from the stream of raw data must be processed all the way into the final tables or rolled back as a single ACID transaction
        BEGIN TRANSACTION; 

        -- Create a table for flattened JSON menu. A permanent table is needed to match order items to menu items.
        create or replace table identifier(:flat_tbl)
        -- create or replace table flat_toast_menu
        as
        select
            raw.restaurantguid::string as restaurant_guid,
            to_timestamp_ltz(raw.lastupdated::string, ''YYYY-MM-DDTHH24:MI:SS.FF3+TZHTZM'') as last_updated,
            f1.value:name::string as menu_name,
            f2.value:name::string as menu_group_name,
            f2.value:multiLocationId::string as menu_group_multilocation_id,
            f2.value:itemTags::string as menu_group_itemTags,
            f2.value:visibility::string as menu_group_visibility,
            f3.value:name::string as menu_item_name,
            f3.value:guid::string as menu_item_guid,
            f3.value:multiLocationId::string as multilocation_id,
            f3.value:description::string as description,
            f3.value:visibility::array as visibility,
            f3.value:price::number(38,2) as price,
            f3.value:pricingStrategy::string as pricing_strategy,
            f3.value:pricingRules::string as pricingRules,
            f3.value:isDeferred::boolean as is_deferred,
            f3.value:isDiscountable::boolean as is_discountable,
            f3.value:salesCategory.name::string as sales_category_name,
            f3.value:taxInfo::array as tax_info,
            f3.value:itemTags::variant as item_tags,
            f3.value:plu::string as plu,
            f3.value:sku::string as sku,
            f3.value:calories::string as calories,
            f3.value:unitOfMeasure::string as unitOfMeasure,
            f3.value:portions::array as portions,
            f3.value:modifierGroupReferences::array as modifier_group_references,
            f3.value:kitchenNamens::string as kitchen_name,
            f3.value:prepTime::string as prep_time,
            f3.value:prepStations::array as prep_stations,
            f3.value:contentAdvisories.alcohol.containsAlcohol::boolean as contains_alcohol,
            f3.value:taxInclusion::string as tax_inclusion
        from identifier(:raw_name) raw,
            lateral flatten( input => raw.menus, recursive => true) f1,
            lateral flatten( input => f1.value:menuGroups) f2,
            lateral flatten( input => f2.value:menuItems ) f3
        ;

        -- Add item modifiers from Toast menu that are actually products
        insert into identifier(:flat_tbl)
        select
            raw.restaurantguid::string as restaurant_guid,
            to_timestamp_ltz(raw.lastupdated::string, ''YYYY-MM-DDTHH24:MI:SS.FF3+TZHTZM'') as last_updated,
            ''modifierOptionReferences'' as menu_name,
            null as menu_group_name,
            null as menu_group_multilocation_id,
            null as menu_group_itemTags,
            null as menu_group_visibility,
            f1.value:name::string as menu_item_name,
            f1.value:guid::string as menu_item_guid,
            f1.value:multiLocationId::string as multilocation_id,
            f1.value:description::string as description,
            f1.value:visibility::array as visibility,
            f1.value:price::number(38,2) as price,
            f1.value:pricingStrategy::string as pricing_strategy,
            f1.value:pricingRules::string as pricingRules,
            f1.value:isDeferred::boolean as is_deferred,
            f1.value:isDiscountable::boolean as is_discountable,
            f1.value:salesCategory.name::string as sales_category_name,
            f1.value:taxInfo::array as tax_info,
            f1.value:itemTags::variant as item_tags,
            f1.value:plu::string as plu,
            f1.value:sku::string as sku,
            f1.value:calories::string as calories,
            f1.value:unitOfMeasure::string as unitOfMeasure,
            f1.value:portions::array as portions,
            f1.value:modifierGroupReferences::array as modifier_group_references,
            f1.value:kitchenNamens::string as kitchen_name,
            f1.value:prepTime::string as prep_time,
            f1.value:prepStations::array as prep_stations,
            f1.value:contentAdvisories.alcohol.containsAlcohol::boolean as contains_alcohol,
            f1.value:taxInclusion::string as tax_inclusion
         -- from identifier(:raw_stream) raw,
        from identifier(:raw_name) raw,
            lateral flatten( input => raw.modifierOptionReferences) f1
            -- lateral flatten( input => f1.value:itemTags) f2
        -- where f2.value:name::string=''Value''
        ;

       -- Add any new dim_customer dimension records found in the flattened data before inserting facts
        call sp_toast_menus_flat_to_dim_product(:flat_tbl);
        
        COMMIT;

        RETURN true;
    ELSE
        -- There are no new records in the stream
        RETURN false;
    END IF;
END;
';
