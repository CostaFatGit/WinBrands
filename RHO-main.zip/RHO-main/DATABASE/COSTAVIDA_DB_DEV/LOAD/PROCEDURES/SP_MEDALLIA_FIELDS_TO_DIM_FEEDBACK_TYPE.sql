-- PROCEDURES: SP_MEDALLIA_FIELDS_TO_DIM_FEEDBACK_TYPE
-- Generated on: 2025-06-05 11:29:36
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_MEDALLIA_FIELDS_TO_DIM_FEEDBACK_TYPE"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN

    -- Flatten the Medallia data dictionary and publish a new version to the STAGE schema.
    create or replace table stage.medallia_fields_dictionary as
    select
      f1.value:id::string as id
      ,f1.value:name::string as name
      ,f1.value:datatype::string as data_type
      ,f1.value:filterable::boolean as filterable
      ,f1.value:multivalued::boolean as multivalued
      ,ifnull(f2.value:id::string,'''') as option_id
      ,ifnull(f2.value:name::string,'''') as option_name
    from load.raw_medallia_queryapi_all_fields load,
      lateral flatten( input => load.data, path => ''fields.nodes'' ) f1
      ,lateral flatten( input => f1.value:options, outer => true ) f2
    ;
    
    -- Update DIM_FEEDBACK_TYPE records with changes to Medallia source codes from the Medallia data dictionary.
    
    update public.dim_feedback_type dim
    set 
      feedback_source_category = dict.option_name
      , record_change_time = current_timestamp()
      , record_change_reason = ''Update to Medallia fields dictionary''
    from stage.medallia_fields_dictionary dict
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_source_category_id=dict.option_id
      and dict.id = ''e_cv_feedback_program_enum''
      and ifnull(dim.feedback_source_category <> dict.option_name, true)
    ;
    
    update public.dim_feedback_type dim
    set 
      feedback_source_subcategory = dict.option_name
      , record_change_time = current_timestamp()
      , record_change_reason = ''Update to Medallia fields dictionary''
    from stage.medallia_fields_dictionary dict
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_source_subcategory_id=dict.option_id
      and dict.id = ''e_cv_survey_type_enum''
      and ifnull(dim.feedback_source_subcategory <> dict.option_name, true)
    ;
    
    update public.dim_feedback_type dim
    set 
      feedback_source_item = dict.name
      , record_change_time = current_timestamp()
      , record_change_reason = ''Update to Medallia fields dictionary''
    from stage.medallia_fields_dictionary dict
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_source_item_id=dict.id
      and ifnull(dim.feedback_source_item <> dict.name, true)
    ;
    
    update public.dim_feedback_type dim
    set 
      feedback_source_item_option = dict.option_name
      , record_change_time = current_timestamp()
      , record_change_reason = ''Update to Medallia fields dictionary''
    from stage.medallia_fields_dictionary dict
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_source_item_id=dict.id
      and dim.feedback_source_item_option_id=dict.option_id
      and ifnull(dim.feedback_source_item_option <> dict.option_name, true)
    ;
    
    -- Set default mappings of Medallia source codes to Costa Vida business codes in DIM_FEEDBACK_TYPE.
    update public.dim_feedback_type dim
    set 
      dim.feedback_category = ''CUSTOMER SURVEY''
      , record_change_time = current_timestamp()
      , record_change_reason = ''Set default FEEDBACK_CATEGORY''
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_source_category = ''VoC''
      and dim.feedback_category = ''''
      or dim.feedback_category is null
    ;
    
    update public.dim_feedback_type dim
    set 
      dim.feedback_subcategory = dim.feedback_source_subcategory
      , record_change_time = current_timestamp()
      , record_change_reason = ''Set default FEEDBACK_SUBCATEGORY''
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_subcategory = ''''
      or dim.feedback_category is null
    ;
    
    update public.dim_feedback_type dim
    set 
      dim.feedback_item = dim.feedback_source_item
      , record_change_time = current_timestamp()
      , record_change_reason = ''Set default FEEDBACK_ITEM''
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_item = ''''
      or dim.feedback_item is null
    ;
    
    update public.dim_feedback_type dim
    set 
      dim.feedback_item = ''Overall Experience''
      , record_change_time = current_timestamp()
      , record_change_reason = ''Normalize FEEDBACK_ITEM across surveys''
    where 
      dim.feedback_source = ''MEDALLIA''
      and dim.feedback_item = ''Overall Satisfaction''
    ;

END
';
