-- PROCEDURES: SP_TEST
-- Generated on: 2025-06-05 11:29:42
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_TEST"("ITEM_COLUMN" VARCHAR(16777216))
RETURNS NUMBER(38,0)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
    DECLARE
      feedback_src varchar DEFAULT ''MEDALLIA'';
      init_status varchar DEFAULT ''PENDING_REVIEW'';
      eff_date date DEFAULT to_date(''2000-01-01'');
      end_date date DEFAULT to_date(''2100-01-01'');
      chg_reason varchar DEFAULT ''Added from Medallia API'';
      chg_time timestamp_ltz DEFAULT current_timestamp(3);
      is_cur boolean DEFAULT true;
    BEGIN

        select distinct
          m.e_cv_feedback_program_enum as feedback_source_category_id,
          m.e_cv_survey_type_enum as feedback_source_subcategory_id,
          iff(:item_column is not null, :item_column, null) as feedback_source_item_id
        from 
          -- medallia_voc_survey_stream m
          medallia_voc_survey m
        where feedback_source_item_id is not null
        ;

      RETURN 0;
    END
  ';
