-- PROCEDURES: SP_MEDALLIA_VOC_FLAT_TO_FEEDBACK_TYPE
-- Generated on: 2025-06-05 11:29:37
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_MEDALLIA_VOC_FLAT_TO_FEEDBACK_TYPE"("FLAT_TABLE" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
    DECLARE
      feedback_src varchar DEFAULT ''MEDALLIA'';
      init_status varchar DEFAULT ''PENDING_REVIEW'';
      eff_date date DEFAULT to_date(''2000-01-01'');
      end_date date DEFAULT to_date(''2100-01-01'');
      chg_reason varchar DEFAULT ''Added from Medallia API'';
      chg_time timestamp_ltz DEFAULT current_timestamp(3);
      is_cur boolean DEFAULT true;
    BEGIN
      merge into public.dim_feedback_type ft
      using 
      (
        select distinct
          m.e_cv_feedback_program_enum as feedback_source_category_id,
          m.e_cv_survey_type_enum as feedback_source_subcategory_id,
          feedback_item as feedback_source_item_id,
          iff(is_comment, ''cmt'', feedback_selection) as feedback_source_item_option_id,
          is_comment as is_comment
        from 
          -- medallia_voc_survey_stream m
          identifier(:flat_table) m
        where
          feedback_source_item_id is not null
      ) as newft
      on
        newft.feedback_source_category_id = ft.feedback_source_category_id
        and newft.feedback_source_subcategory_id = ft.feedback_source_subcategory_id
        and newft.feedback_source_item_id = ft.feedback_source_item_id
        and newft.feedback_source_item_option_id = ft.feedback_source_item_option_id
      when not matched then 
        insert (feedback_category, feedback_subcategory, feedback_item, feedback_source, feedback_source_category, feedback_source_subcategory, feedback_source_item, feedback_source_item_option, feedback_source_category_id, feedback_source_subcategory_id, feedback_source_item_id, feedback_source_item_option_id, is_comment, status, record_effective_date, record_end_date, record_change_reason, record_change_time, record_is_current)
        values ('''', '''', '''', :feedback_src, null, null, null, null, newft.feedback_source_category_id, newft.feedback_source_subcategory_id, newft.feedback_source_item_id, newft.feedback_source_item_option_id, newft.is_comment, :init_status, :eff_date, :end_date, :chg_reason, :chg_time, :is_cur)
      ; 

      RETURN true;
    END
  ';
