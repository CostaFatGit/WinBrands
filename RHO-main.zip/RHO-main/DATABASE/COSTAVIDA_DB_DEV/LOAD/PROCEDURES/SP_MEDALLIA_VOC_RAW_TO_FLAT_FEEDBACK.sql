-- PROCEDURES: SP_MEDALLIA_VOC_RAW_TO_FLAT_FEEDBACK
-- Generated on: 2025-06-05 11:29:37
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_MEDALLIA_VOC_RAW_TO_FLAT_FEEDBACK"("RAW_TABLE_STREAM" VARCHAR(16777216), "FLAT_TABLE" VARCHAR(16777216), "SELECTION_COLUMN" VARCHAR(16777216), "IS_COMMENT" BOOLEAN)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN
    -- Flatten raw JSON to columns
    let stmt varchar := 
    ''insert into '' || :flat_table|| '' (
        id, 
        e_status, 
        e_creation_date,
        e_response_date,
        e_cv_feedback_program_enum,
        e_cv_survey_type_enum,
        e_unitid,
        e_cv_voc_posref_txt,
        q_cv_voc_receipt_code_check_num_txt,
        q_cv_voc_receipt_code_datetime_txt,
        e_cv_voc_time_placed_date_time,
        q_costavida_voc_visit_day_date,
        q_costavida_day_part_enum,
        feedback_item,
        feedback_selection,
        is_comment
    )
    select distinct
        raw."_airbyte_data":id::string,
        raw."_airbyte_data":e_status.values[0]::string, 
        raw."_airbyte_data":e_creationdate.values[0]::string as e_creationdate,
        raw."_airbyte_data":e_responsedate.values[0]::string as e_responsedate,
        raw."_airbyte_data":e_cv_feedback_program_enum.values[0]::string,
        raw."_airbyte_data":e_cv_survey_type_enum.values[0]::string,
        raw."_airbyte_data":e_unitid.values[0]::string,
        raw."_airbyte_data":e_cv_voc_posref_txt.values[0]::string,
        raw."_airbyte_data":q_cv_voc_receipt_code_check_num_txt.values[0]::string,
        raw."_airbyte_data":q_cv_voc_receipt_code_datetime_txt.values[0]::string,
        raw."_airbyte_data":e_cv_voc_time_placed_date_time.values[0]::string,
        raw."_airbyte_data":q_costavida_voc_visit_day_date.values[0]::string,
        raw."_airbyte_data":q_costavida_day_part_enum.values[0]::string,
        \\'''' || :selection_column || ''\\'' as feedback_item, 
        f1.value::string as feedback_selection,
        '' || :is_comment || '' as is_comment
    from '' || :raw_table_stream || '' raw,
        lateral flatten( input => raw."_airbyte_data", path => \\'''' || :selection_column || ''.values\\'' ) f1
    where 
        feedback_selection is not null''
    ;
    let rs resultset := (EXECUTE IMMEDIATE :stmt);

RETURN true;
END;
';
