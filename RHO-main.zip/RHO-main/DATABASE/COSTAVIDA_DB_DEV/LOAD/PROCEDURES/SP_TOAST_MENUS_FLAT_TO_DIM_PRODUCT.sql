-- PROCEDURES: SP_TOAST_MENUS_FLAT_TO_DIM_PRODUCT
-- Generated on: 2025-06-05 11:29:44
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_TOAST_MENUS_FLAT_TO_DIM_PRODUCT"("FLAT_TABLE" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS '
    DECLARE
      src varchar DEFAULT ''TOAST'';
      init_status varchar DEFAULT ''PENDING_REVIEW'';
      eff_date date DEFAULT to_date(''2000-01-01'');
      end_date date DEFAULT to_date(''2100-01-01'');
      chg_time timestamp_ltz DEFAULT current_timestamp(3);
      is_cur boolean DEFAULT true;
    BEGIN
      merge into public.dim_product dim
      using 
      (
        select *
        from 
        (
          select *, row_number() over(partition by plu order by plu) as rownum
          from 
            identifier(:flat_table)
          where 
            plu is not null
        )
        where rownum=1
      ) as flat
      on
        flat.plu = dim.product_number
      when matched then update
      set
        dim.toast_product_name=flat.menu_item_name,
        dim.pos_product_name=flat.menu_item_name,
        dim.pos_product_category=flat.sales_category_name,
        dim.in_pos_menu=iff(array_contains(''POS''::variant, flat.VISIBILITY), true, false),
        dim.in_online_menu=iff(array_contains(''TOAST_ONLINE_ORDERING''::variant, flat.VISIBILITY), true, false),
        dim.in_partner_menu=iff(array_contains(''ORDERING_PARTNERS''::variant, flat.VISIBILITY), true, false),
        dim.price=flat.price,
        record_change_reason = ''Updated from Toast menus API'', 
        record_change_time = :chg_time
      when not matched then insert 
        (
          product_number, 
          product_name, 
          product_category, 
          toast_product_name, 
          pos_product_name, 
          pos_product_category,
          in_pos_menu,
          in_online_menu,
          in_partner_menu,
          price,
          tortilla_count, 
          entree_type, 
          protein_type,
          status, 
          record_effective_date, 
          record_end_date, 
          record_change_reason, 
          record_change_time, 
          record_is_current
        )
        values 
        (
          flat.plu, 
          flat.menu_item_name,
          case
            when upper(flat.sales_category_name) like ''ENTREE%'' then ''Entree''
            when upper(flat.sales_category_name) like ''SIDE%'' then ''Side''
            when upper(flat.sales_category_name) like ''KID%'' then ''Kids''
            when upper(flat.sales_category_name) like ''APPETIZER%'' then ''Appetizer''
            when upper(flat.sales_category_name) like ''BEVERAGE%'' then ''Beverage''
            when upper(flat.sales_category_name) like ''BREAKFAST%'' then ''Breakfast''
            when upper(flat.sales_category_name) like ''DESSERT%'' then ''Dessert''
            when upper(flat.sales_category_name) like ''OPTION%'' then ''Option''
            when upper(flat.sales_category_name) like ''CATERING%'' then ''Catering''
            when upper(flat.sales_category_name) like ''COMBO%'' then ''Combo Meal''
          end,
          flat.menu_item_name, 
          flat.menu_item_name, 
          flat.sales_category_name,
          iff(array_contains(''POS''::variant, flat.VISIBILITY), true, false),
          iff(array_contains(''TOAST_ONLINE_ORDERING''::variant, flat.VISIBILITY), true, false),
          iff(array_contains(''ORDERING_PARTNERS''::variant, flat.VISIBILITY), true, false),
          flat.price,
          null,
          null,
          null,
           :init_status, 
           :eff_date, 
           :end_date, 
           ''Inserted from Toast menus API'', 
           :chg_time, 
           :is_cur
        )
      ; 

      RETURN true;
    END
  ';
