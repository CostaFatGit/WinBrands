-- VIEWS: V_OVATION
-- Generated on: 2025-06-05 11:29:25
-- Database: COSTAVIDA_DB_DEV

create or replace view V_OVATION(
	CUSTOMER_KEY,
	SURVEY_ID,
	SURVEY_TIMESTAMP_LOCAL,
	RATING,
	SOURCE,
	FEEDBACK,
	LOCATION_NAME,
	ORDER_READY,
	CUSTOM_QUESTION,
	CUSTOM_ANSWER,
	CUSTOM_ANSWER1
) as
SELECT
  F.CUSTOMER_KEY
 ,F.SURVEY_ID
 ,F.SURVEY_TIMESTAMP_LOCAL
 ,F.RATING
 ,F.SOURCE
 ,F.FEEDBACK
 ,F.LOCATION_NAME
 ,F.ORDER_READY
 ,F.CUSTOM_QUESTION
 ,F.CUSTOM_ANSWER
 ,F.CUSTOM_ANSWER1
FROM
(
    SELECT
      DT.CUSTOMER_KEY
     ,DT.SURVEY_ID
     ,DT.SURVEY_TIMESTAMP_LOCAL
     ,DT.RATING
     ,DT.SOURCE
     ,DT.FEEDBACK
     ,DT.LOCATION_NAME
     ,DT.ORDER_READY
     ,DT.CUSTOM_QUESTION
     ,DT.CUSTOM_ANSWER
     ,DT.CUSTOM_ANSWER1
     ,ROW_NUMBER() OVER(PARTITION BY SURVEY_ID ORDER BY ORDER_READY ASC) AS RN
    FROM
    (
        SELECT
          C.CUSTOMER_KEY
         ,O.SURVEY_ID
         ,O.SURVEY_TIMESTAMP_LOCAL
         ,O.RATING
         ,O.SOURCE
         ,O.FEEDBACK
         ,O.LOCATION_NAME
         ,O."order.ready_timestamp_local" AS ORDER_READY
         ,O."custom_questions[0].question" AS CUSTOM_QUESTION
         ,O."custom_questions[0].answer[0]" AS CUSTOM_ANSWER
         ,NULL AS CUSTOM_ANSWER1
        FROM
          LOAD.RAW_OVATION O
        LEFT JOIN
          RESTRICTED.DIM_CUSTOMER_PII C ON TO_VARCHAR(O."customer.phone") = C.PHONE
        UNION
        SELECT
          C.CUSTOMER_KEY
         ,O.SURVEY_ID
         ,O.SURVEY_TIMESTAMP_LOCAL
         ,O.RATING
         ,O.SOURCE
         ,O.FEEDBACK
         ,O.LOCATION_NAME
         ,O."order.ready_timestamp_local" AS ORDER_READY
         ,O."custom_questions[0].question" AS CUSTOM_QUESTION
         ,O."custom_questions[0].answer[0]" AS CUSTOM_ANSWER
         ,O."custom_questions[0].answer[1]" AS CUSTOM_ANSWER1
        FROM
          LOAD.RAW_OVATION_11112024 O
        LEFT JOIN
          RESTRICTED.DIM_CUSTOMER_PII C ON TO_VARCHAR(O."customer.phone") = C.PHONE
        UNION
        SELECT
          C.CUSTOMER_KEY
         ,O.SURVEY_ID
         ,O.SURVEY_TIMESTAMP_LOCAL
         ,O.RATING
         ,O.SOURCE
         ,O.FEEDBACK
         ,O.LOCATION_NAME
         ,O."order.ready_timestamp_local" AS ORDER_READY
         ,O."custom_questions[0].question" AS CUSTOM_QUESTION
         ,O."custom_questions[0].answer[0]" AS CUSTOM_ANSWER
         ,O."custom_questions[0].answer[1]" AS CUSTOM_ANSWER1
        FROM
          LOAD.RAW_OVATION_11182024 O
        LEFT JOIN
          RESTRICTED.DIM_CUSTOMER_PII C ON TO_VARCHAR(O."customer.phone") = C.PHONE
        UNION
        SELECT
          C.CUSTOMER_KEY
         ,O.SURVEY_ID
         ,O.SURVEY_TIMESTAMP_LOCAL
         ,O.RATING
         ,O.SOURCE
         ,O.FEEDBACK
         ,O.LOCATION_NAME
         ,O."order.ready_timestamp_local" AS ORDER_READY
         ,O."custom_questions[0].question" AS CUSTOM_QUESTION
         ,O."custom_questions[0].answer[0]" AS CUSTOM_ANSWER
         ,O."custom_questions[0].answer[1]" AS CUSTOM_ANSWER1
        FROM
          LOAD.RAW_OVATION_11252024 O
        LEFT JOIN
          RESTRICTED.DIM_CUSTOMER_PII C ON TO_VARCHAR(O."customer.phone") = C.PHONE
        UNION
        SELECT
          C.CUSTOMER_KEY
         ,O.SURVEY_ID
         ,O.SURVEY_TIMESTAMP_LOCAL
         ,O.RATING
         ,O.SOURCE
         ,O.FEEDBACK
         ,O.LOCATION_NAME
         ,O."order.ready_timestamp_local" AS ORDER_READY
         ,O."custom_questions[0].question" AS CUSTOM_QUESTION
         ,O."custom_questions[0].answer[0]" AS CUSTOM_ANSWER
         ,O."custom_questions[0].answer[1]" AS CUSTOM_ANSWER1
        FROM
          LOAD.RAW_OVATION_12032024 O
        LEFT JOIN
          RESTRICTED.DIM_CUSTOMER_PII C ON TO_VARCHAR(O."customer.phone") = C.PHONE
    ) DT
) F
WHERE
  F.RN = 1;
