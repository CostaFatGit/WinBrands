-- TABLES: A_TEST
-- Generated on: 2025-06-05 11:28:53
-- Database: COSTAVIDA_DB_DEV

create or replace TABLE A_TEST (
	XYZ TIMESTAMP_NTZ(9)
);
