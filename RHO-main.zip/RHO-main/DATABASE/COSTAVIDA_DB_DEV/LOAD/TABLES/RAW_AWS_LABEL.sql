-- TABLES: RAW_AWS_LABEL
-- Generated on: 2025-06-05 11:28:58
-- Database: COSTAVIDA_DB_DEV

create or replace TABLE RAW_AWS_LABEL (
	LABEL_ID NUMBER(38,0),
	LABELNAME VARCHAR(100),
	constraint PK_RAW_AWS_LABEL primary key (LABEL_ID)
);
