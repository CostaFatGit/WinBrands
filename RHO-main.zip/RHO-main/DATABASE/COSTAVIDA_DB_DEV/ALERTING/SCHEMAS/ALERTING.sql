-- SCHEMAS: ALERTING
-- Generated on: 2025-06-05 11:28:38
-- Database: COSTAVIDA_DB_DEV

create or replace schema ALERTING;

create or replace TABLE ALERT (
	ALERT_ID NUMBER(38,0) NOT NULL autoincrement start 1 increment 1 noorder,
	ALERT_NAME VARCHAR(256) NOT NULL,
	ALERT_DESCRIPTION VARCHAR(256) NOT NULL,
	NOTIFICATION_INTEGRATION_NAME VARCHAR(256) NOT NULL,
	EMAIL_ALERT_IF_EXIST_SQL VARCHAR(8000) NOT NULL,
	TROUBLESHOOTING_SQL VARCHAR(8000),
	EMAIL_RECIPIENTS VARCHAR(512) NOT NULL,
	EMAIL_SUBJECT VARCHAR(256) NOT NULL,
	EMAIL_BODY VARCHAR(8000) NOT NULL,
	DATABASE_ASSIGNMENT VARCHAR(256) NOT NULL,
	MIN_MINUTES_BETWEEN_ALERT NUMBER(38,0) NOT NULL,
	LAST_ALERT_SENT_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	ENABLED_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	CREATED_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	LAST_CHECKED_BEGIN_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	LAST_CHECKED_END_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	primary key (ALERT_ID)
);
create or replace TABLE ALERT_LOG (
	ALERT_ID NUMBER(38,0) NOT NULL,
	SENT_UTC_DATETIME TIMESTAMP_NTZ(9) NOT NULL,
	ALERT_SENT_TO VARCHAR(512) NOT NULL,
	EMAIL_MESSAGE_SENT VARCHAR(8000) NOT NULL,
	primary key (ALERT_ID, SENT_UTC_DATETIME),
	foreign key (ALERT_ID) references COSTAVIDA_DB_DEV.ALERTING.ALERT(ALERT_ID)
);
create or replace view V_FAILED_TASKS(
	SENDALERT,
	NAME,
	QUERY_TEXT,
	CONDITION_TEXT,
	SCHEMA_NAME,
	TASK_SCHEMA_ID,
	DATABASE_NAME,
	TASK_DATABASE_ID,
	SCHEDULED_TIME,
	COMPLETED_TIME,
	STATE,
	RETURN_VALUE,
	QUERY_ID,
	QUERY_START_TIME,
	ERROR_CODE,
	ERROR_MESSAGE,
	GRAPH_VERSION,
	RUN_ID,
	ROOT_TASK_ID,
	SCHEDULED_FROM,
	INSTANCE_ID,
	ATTEMPT_NUMBER,
	CONFIG,
	QUERY_HASH,
	QUERY_HASH_VERSION,
	QUERY_PARAMETERIZED_HASH,
	QUERY_PARAMETERIZED_HASH_VERSION,
	GRAPH_RUN_GROUP_ID,
	BACKFILL_INFO
) as
SELECT
  1 AS SENDALERT
 ,*
FROM 
  SNOWFLAKE.ACCOUNT_USAGE.TASK_HISTORY 
WHERE 
  STATE = 'FAILED' 
  AND COMPLETED_TIME > DATEADD(HOUR, -25, GETDATE())
  --Troubleshooting this error and I don't want to keep getting alerts while I do.
  --Need to find a good way to disable alerts for specific tasks wihtout hard coding
  AND (NAME <> 'T_TOAST_ORDERUPDATES_10_S3_UPDATES_TO_SNOW' AND ERROR_MESSAGE NOT ILIKE '%SQL execution internal error:%');
CREATE OR REPLACE PROCEDURE "SP_SEND_ALERTS"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  Send_Alert INT DEFAULT -1;
  Notification_Integration VARCHAR(16777216);
  Email_Addresses VARCHAR(16777216);
  Email_Subject VARCHAR(16777216);
  Email_Body VARCHAR(16777216);
  Alert_SQL VARCHAR(16777216) DEFAULT '''';
  Troubleshooting_SQL VARCHAR(16777216) DEFAULT '''';
  Database_Assignment VARCHAR(16777216) DEFAULT '''';
  Current_Database VARCHAR(16777216) DEFAULT '''';
  Error_Message VARCHAR(16777216) DEFAULT '''';
  troubleshooting_results VARCHAR(16777216) DEFAULT '''';
  column_headers VARCHAR(16777216) DEFAULT '''';
  Alert_ID INT;
  Alert_Cursor CURSOR 
    FOR  
        SELECT
          EMAIL_ALERT_IF_EXIST_SQL
         ,NOTIFICATION_INTEGRATION_NAME
         ,EMAIL_RECIPIENTS
         ,EMAIL_SUBJECT
         ,EMAIL_BODY
         ,ALERT_ID
         ,TROUBLESHOOTING_SQL
         ,DATABASE_ASSIGNMENT
        FROM
          ALERTING.ALERT
        WHERE
          ENABLED_UTC_DATETIME < CURRENT_TIMESTAMP()
          AND DATEDIFF(MINUTE, LAST_CHECKED_BEGIN_UTC_DATETIME, CURRENT_TIMESTAMP()) >= MIN_MINUTES_BETWEEN_ALERT;

BEGIN

    FOR rec IN Alert_Cursor DO
        Alert_SQL := rec.EMAIL_ALERT_IF_EXIST_SQL;
        Notification_Integration := rec.NOTIFICATION_INTEGRATION_NAME;
        Email_Addresses := rec.EMAIL_RECIPIENTS;
        Email_Subject := rec.EMAIL_SUBJECT;
        Email_Body := rec.EMAIL_BODY;
        Send_Alert := -1;
        Alert_ID := rec.ALERT_ID;
        Troubleshooting_SQL := rec.TROUBLESHOOTING_SQL;
        Database_Assignment := rec.DATABASE_ASSIGNMENT;

        Current_Database := (SELECT CURRENT_DATABASE());

        UPDATE
          ALERTING.ALERT
        SET
          LAST_CHECKED_BEGIN_UTC_DATETIME = CURRENT_TIMESTAMP()
        WHERE
          ALERT_ID = :Alert_ID;

        IF ((:Current_Database = :Database_Assignment) OR (:Database_Assignment = ''ANY'')) THEN

            BEGIN
                EXECUTE IMMEDIATE Alert_SQL;
            EXCEPTION
                WHEN other THEN
                    Error_Message := CONCAT(''Error With ALERT_ID = '', :Alert_ID, CHR(10), CHR(10), SQLERRM);
                    CALL SYSTEM$SEND_EMAIL(:Notification_Integration, :Email_Addresses, :Email_Subject, :Error_Message);
            END;
    
            Send_Alert := (SELECT $1 FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
            Email_Body := CONCAT(:Email_Body, CHR(10), CHR(10), IFNULL(:Troubleshooting_SQL, ''''), CHR(10), CHR(10), ''SELECT * FROM ALERTING.ALERT WHERE ALERT_ID = '', :Alert_ID);
    
            IF (Send_Alert = 1) THEN
            
                -- Execute troubleshooting SQL if it exists and append results to email body
                IF (Troubleshooting_SQL != '''') THEN
                    BEGIN
                        LET results RESULTSET := (EXECUTE IMMEDIATE :Troubleshooting_SQL);
                        
                        -- Format the results with headers
                        LET agg_results VARCHAR := (
                            SELECT 
                                REPLACE(
                                    REPLACE(
                                        TO_VARCHAR(ARRAY_AGG(OBJECT_CONSTRUCT(*))),
                                        ''},{'',
                                        CHR(10)
                                    ),
                                    ''[]"'',
                                    ''''
                                )
                            FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
                        );
                        
                        Email_Body := CONCAT(
                            :Email_Body, 
                            CHR(10), CHR(10),
                            ''Troubleshooting Results:'', CHR(10),
                            ''----------------------------------------'', CHR(10),
                            :agg_results
                        );
                    EXCEPTION
                        WHEN other THEN
                            Error_Message := CONCAT(
                                ''Error executing troubleshooting SQL for ALERT_ID = '', 
                                :Alert_ID, 
                                CHR(10), 
                                ''Troubleshooting SQL: '', 
                                :Troubleshooting_SQL,
                                CHR(10), CHR(10),
                                ''Error: '',
                                SQLERRM
                            );
                            Email_Body := CONCAT(
                                :Email_Body,
                                CHR(10), CHR(10),
                                ''Troubleshooting Error:'', CHR(10),
                                ''----------------------------------------'', CHR(10),
                                :Error_Message
                            );
                    END;
                END IF;
    
                CALL SYSTEM$SEND_EMAIL(:Notification_Integration, :Email_Addresses, :Email_Subject, :Email_Body);
    
                INSERT INTO
                  ALERTING.ALERT_LOG(ALERT_ID, SENT_UTC_DATETIME, ALERT_SENT_TO, EMAIL_MESSAGE_SENT)
                SELECT
                  :Alert_ID
                 ,CURRENT_TIMESTAMP()
                 ,:Email_Addresses
                 ,:Email_Body;
    
                UPDATE
                  ALERTING.ALERT
                SET
                  LAST_ALERT_SENT_UTC_DATETIME = CURRENT_TIMESTAMP()
                WHERE
                  ALERT_ID = :Alert_ID;
                
            END IF;

        END IF;

        UPDATE
          ALERTING.ALERT
        SET
          LAST_CHECKED_END_UTC_DATETIME = CURRENT_TIMESTAMP()
        WHERE
          ALERT_ID = :Alert_ID;

    END FOR;

END;
';
