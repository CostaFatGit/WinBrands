-- PROCEDURES: SP_SEND_ALERTS
-- Generated on: 2025-06-05 11:29:41
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_SEND_ALERTS"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  Send_Alert INT DEFAULT -1;
  Notification_Integration VARCHAR(16777216);
  Email_Addresses VARCHAR(16777216);
  Email_Subject VARCHAR(16777216);
  Email_Body VARCHAR(16777216);
  Alert_SQL VARCHAR(16777216) DEFAULT '''';
  Troubleshooting_SQL VARCHAR(16777216) DEFAULT '''';
  Database_Assignment VARCHAR(16777216) DEFAULT '''';
  Current_Database VARCHAR(16777216) DEFAULT '''';
  Error_Message VARCHAR(16777216) DEFAULT '''';
  troubleshooting_results VARCHAR(16777216) DEFAULT '''';
  column_headers VARCHAR(16777216) DEFAULT '''';
  Alert_ID INT;
  Alert_Cursor CURSOR 
    FOR  
        SELECT
          EMAIL_ALERT_IF_EXIST_SQL
         ,NOTIFICATION_INTEGRATION_NAME
         ,EMAIL_RECIPIENTS
         ,EMAIL_SUBJECT
         ,EMAIL_BODY
         ,ALERT_ID
         ,TROUBLESHOOTING_SQL
         ,DATABASE_ASSIGNMENT
        FROM
          ALERTING.ALERT
        WHERE
          ENABLED_UTC_DATETIME < CURRENT_TIMESTAMP()
          AND DATEDIFF(MINUTE, LAST_CHECKED_BEGIN_UTC_DATETIME, CURRENT_TIMESTAMP()) >= MIN_MINUTES_BETWEEN_ALERT;

BEGIN

    FOR rec IN Alert_Cursor DO
        Alert_SQL := rec.EMAIL_ALERT_IF_EXIST_SQL;
        Notification_Integration := rec.NOTIFICATION_INTEGRATION_NAME;
        Email_Addresses := rec.EMAIL_RECIPIENTS;
        Email_Subject := rec.EMAIL_SUBJECT;
        Email_Body := rec.EMAIL_BODY;
        Send_Alert := -1;
        Alert_ID := rec.ALERT_ID;
        Troubleshooting_SQL := rec.TROUBLESHOOTING_SQL;
        Database_Assignment := rec.DATABASE_ASSIGNMENT;

        Current_Database := (SELECT CURRENT_DATABASE());

        UPDATE
          ALERTING.ALERT
        SET
          LAST_CHECKED_BEGIN_UTC_DATETIME = CURRENT_TIMESTAMP()
        WHERE
          ALERT_ID = :Alert_ID;

        IF ((:Current_Database = :Database_Assignment) OR (:Database_Assignment = ''ANY'')) THEN

            BEGIN
                EXECUTE IMMEDIATE Alert_SQL;
            EXCEPTION
                WHEN other THEN
                    Error_Message := CONCAT(''Error With ALERT_ID = '', :Alert_ID, CHR(10), CHR(10), SQLERRM);
                    CALL SYSTEM$SEND_EMAIL(:Notification_Integration, :Email_Addresses, :Email_Subject, :Error_Message);
            END;
    
            Send_Alert := (SELECT $1 FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
            Email_Body := CONCAT(:Email_Body, CHR(10), CHR(10), IFNULL(:Troubleshooting_SQL, ''''), CHR(10), CHR(10), ''SELECT * FROM ALERTING.ALERT WHERE ALERT_ID = '', :Alert_ID);
    
            IF (Send_Alert = 1) THEN
            
                -- Execute troubleshooting SQL if it exists and append results to email body
                IF (Troubleshooting_SQL != '''') THEN
                    BEGIN
                        LET results RESULTSET := (EXECUTE IMMEDIATE :Troubleshooting_SQL);
                        
                        -- Format the results with headers
                        LET agg_results VARCHAR := (
                            SELECT 
                                REPLACE(
                                    REPLACE(
                                        TO_VARCHAR(ARRAY_AGG(OBJECT_CONSTRUCT(*))),
                                        ''},{'',
                                        CHR(10)
                                    ),
                                    ''[]"'',
                                    ''''
                                )
                            FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
                        );
                        
                        Email_Body := CONCAT(
                            :Email_Body, 
                            CHR(10), CHR(10),
                            ''Troubleshooting Results:'', CHR(10),
                            ''----------------------------------------'', CHR(10),
                            :agg_results
                        );
                    EXCEPTION
                        WHEN other THEN
                            Error_Message := CONCAT(
                                ''Error executing troubleshooting SQL for ALERT_ID = '', 
                                :Alert_ID, 
                                CHR(10), 
                                ''Troubleshooting SQL: '', 
                                :Troubleshooting_SQL,
                                CHR(10), CHR(10),
                                ''Error: '',
                                SQLERRM
                            );
                            Email_Body := CONCAT(
                                :Email_Body,
                                CHR(10), CHR(10),
                                ''Troubleshooting Error:'', CHR(10),
                                ''----------------------------------------'', CHR(10),
                                :Error_Message
                            );
                    END;
                END IF;
    
                CALL SYSTEM$SEND_EMAIL(:Notification_Integration, :Email_Addresses, :Email_Subject, :Email_Body);
    
                INSERT INTO
                  ALERTING.ALERT_LOG(ALERT_ID, SENT_UTC_DATETIME, ALERT_SENT_TO, EMAIL_MESSAGE_SENT)
                SELECT
                  :Alert_ID
                 ,CURRENT_TIMESTAMP()
                 ,:Email_Addresses
                 ,:Email_Body;
    
                UPDATE
                  ALERTING.ALERT
                SET
                  LAST_ALERT_SENT_UTC_DATETIME = CURRENT_TIMESTAMP()
                WHERE
                  ALERT_ID = :Alert_ID;
                
            END IF;

        END IF;

        UPDATE
          ALERTING.ALERT
        SET
          LAST_CHECKED_END_UTC_DATETIME = CURRENT_TIMESTAMP()
        WHERE
          ALERT_ID = :Alert_ID;

    END FOR;

END;
';
