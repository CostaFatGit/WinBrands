-- VIEWS: SPENDGO_UPDATE_COMPARISON_VW
-- Generated on: 2025-06-05 11:29:29
-- Database: COSTAVIDA_DB_DEV

create or replace view SPENDGO_UPDATE_COMPARISON_VW(
	EXTERNAL_ID,
	FIRST_NAME,
	LAST_NAME,
	PHONE,
	EMAIL,
	DOB,
	SOURCE,
	OLD_EMAIL_SUBSCRIBE,
	OLD_PUSH_SUBSCRIBE,
	EMAIL_SUBSCRIBE,
	PUSH_SUBSCRIBE,
	FAVORITE_RESTAURANT_NUMBER,
	COUNTRY,
	RESTAURANT_NUMBER
) as
SELECT
    target.External_Id,
    target.first_name,
    target.last_name,
    target.phone,
    target.email,
    target.dob,
    target.source,
    target.email_subscribe AS old_email_subscribe,
    target.push_subscribe AS old_push_subscribe,
    CASE
        WHEN source.email_subscribe = TRUE THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS email_subscribe,
    CASE
        WHEN source.push_subscribe = TRUE THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS push_subscribe,
    target.favorite_restaurant_number,
    target.country,
    target.restaurant_number
FROM COSTAVIDA_DB_PROD.CDR.spendgo_get_ids target
INNER JOIN COSTAVIDA_DB_PROD.CDR.spendgo_cleanup_combined_vw source
ON target.External_Id = source.External_Id;
