-- VIEWS: BRAZE_SECOND_TEST_EXCLUDED_VW
-- Generated on: 2025-06-05 11:29:29
-- Database: COSTAVIDA_DB_DEV

create or replace view BRAZE_SECOND_TEST_EXCLUDED_VW(
	EXTERNAL_ID,
	FIRST_NAME,
	LAST_NAME,
	PHONE,
	EMAIL,
	DOB,
	SOURCE,
	EMAIL_SUBSCRIBE,
	PUSH_SUBSCRIBE,
	FAVORITE_RESTAURANT_NUMBER,
	COUNTRY,
	RESTAURANT_NUMBER,
	MOST_RECENT_VISIT,
	DATE_DIFF,
	RECENCY
) as
SELECT
    b.External_Id,
    b.First_Name,
    b.Last_Name,
    b.Phone,
    b.email,
    b.dob,
    b.source,
    b.email_subscribe,
    b.push_subscribe,
    b.favorite_restaurant_number,
    b.country,
    b.restaurant_number,
    r.Most_Recent_Visit,
    r.Date_Diff,

    CASE
        WHEN r.Most_Recent_Visit IS NULL THEN 'No Visit Yet'
        WHEN r.Date_Diff <= 30 THEN '0-30'
        WHEN r.Date_Diff BETWEEN 31 AND 60 THEN '31-60'
        WHEN r.Date_Diff BETWEEN 61 AND 90 THEN '61-90'
        WHEN r.Date_Diff BETWEEN 91 AND 120 THEN '91-120'
        WHEN r.Date_Diff BETWEEN 121 AND 150 THEN '121-150'
        WHEN r.Date_Diff BETWEEN 151 AND 180 THEN '151-180'
        ELSE '180+'
    END AS Recency
FROM
    COSTAVIDA_DB_PROD.RESTRICTED.BRAZE_SECOND_TEST_EXCLUDED_TEMP b
LEFT JOIN
    COSTAVIDA_DB_PROD.CDR.recency_vw r
ON
    b.External_Id = r.SPENDGO_GUEST_ID
ORDER BY
    r.Most_Recent_Visit DESC;
