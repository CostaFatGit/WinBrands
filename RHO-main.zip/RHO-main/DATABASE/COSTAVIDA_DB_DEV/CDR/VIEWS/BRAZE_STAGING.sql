-- VIEWS: BRAZE_STAGING
-- Generated on: 2025-06-05 11:29:24
-- Database: COSTAVIDA_DB_DEV

create or replace view BRAZE_STAGING(
	UPDATED_AT,
	EXTERNAL_ID,
	FIRST_NAME,
	LAST_NAME,
	PHONE,
	EMAIL,
	DOB,
	SOURCE,
	EMAIL_SUBSCRIBE,
	SUBSCRIBE,
	FAVORITE_RESTAURANT_NUMBER,
	COUNTRY,
	RESTAURANT_NUMBER,
	RECENCY
) as
WITH BASE AS (
        SELECT
            rd.customer_key,
            rd.First_Name,
            rd.Last_Name,
            rd.Phone,
            rd.email,
            rd.birthday,
            dc.source,
            dc.spendgo_guest_id,
            dc.IN_MARKETING_EMAIL,
            dc.IN_MARKETING_PUSH,
            dc.favorite_restaurant_number,
            cm.loyalty_status,
            cm.registered
        FROM
            COSTAVIDA_DB_PROD.RESTRICTED.DIM_CUSTOMER_PII rd
        INNER JOIN COSTAVIDA_DB_PROD.STAGE.DIM_CUSTOMER_DEDUPE_VW dc ON rd.customer_key = dc.customer_key
        LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_MEMBER_CURRENT_VW cm ON (dc.spendgo_guest_id = cm.spendgo_guest_id)
        WHERE
            dc.spendgo_guest_id <> 'UNKNOWN'
            AND dc.spendgo_guest_id IS NOT NULL
            --AND (dc.In_Marketing_Email = True OR dc.in_marketing_push = True)
            AND cm.registered
)
SELECT
    CURRENT_TIMESTAMP AS UPDATED_AT,
    fc.spendgo_guest_id AS External_Id,
    fc.First_Name,
    fc.Last_Name,
    case ca.country 
        when 'US' then fc.Phone
        when 'CA' then '+1'||fc.Phone
        else fc.Phone
    end as phone,
    fc.email,
    CASE
        WHEN TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY') IS NULL THEN NULL
        ELSE TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY')
    END AS dob,
    fc.source,
    CASE
        WHEN fc.IN_MARKETING_EMAIL = True AND email.EMAIL_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS email_subscribe,
    CASE
        WHEN fc.IN_MARKETING_PUSH = True AND sms.SMS_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS subscribe,
    fc.favorite_restaurant_number,
    CASE
        WHEN fc.favorite_restaurant_number = '0000' THEN NULL
        ELSE ca.country
    END AS country,
    ca.restaurant_number,
    COALESCE(recency.RECENCY,'No Visit Yet') as RECENCY
FROM BASE fc
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW ca ON fc.favorite_restaurant_number = ca.restaurant_number
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_SMS_CLEANUP_1 sms ON (fc.spendgo_guest_id = sms.spendgo_guest_id)
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_EMAIL_CLEANUP_1 email ON (fc.spendgo_guest_id = email.spendgo_guest_id)
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.RECENCY_VW recency ON (fc.spendgo_guest_id = recency.spendgo_guest_id)
WHERE (fc.favorite_restaurant_number in (SELECT restaurant_number FROM COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW) or fc.favorite_restaurant_number is null);
