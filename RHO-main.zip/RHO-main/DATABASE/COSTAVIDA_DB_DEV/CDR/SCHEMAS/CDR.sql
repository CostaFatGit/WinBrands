-- SCHEMAS: CDR
-- Generated on: 2025-06-05 11:28:39
-- Database: COSTAVIDA_DB_DEV

create or replace schema CDR COMMENT='Schema for CDR-specific use';

create or replace TABLE CORRECT_SPARKFLY_PHONE_NUMBER_20250319 (
	SPARKFLY_ID NUMBER(38,0),
	SPENDGO_ID VARCHAR(100),
	ENROLLMENT_ID NUMBER(38,0),
	EXTERNAL_ID VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	MATCH_SPENDGO_ID VARCHAR(100),
	CORRECT_PHONE_NUMBER VARCHAR(100)
);
create or replace TABLE DEDUPE (
	UPDATED_AT TIMESTAMP_LTZ(9),
	EXTERNAL_ID VARCHAR(100),
	FIRST_NAME VARCHAR(100),
	LAST_NAME VARCHAR(100),
	PHONE VARCHAR(100),
	EMAIL VARCHAR(100),
	DOB DATE,
	SOURCE VARCHAR(16777216),
	EMAIL_SUBSCRIBE VARCHAR(12),
	PUSH_SUBSCRIBE VARCHAR(12),
	FAVORITE_RESTAURANT_NUMBER VARCHAR(4),
	COUNTRY VARCHAR(16777216),
	RESTAURANT_NUMBER VARCHAR(4)
);
create or replace TABLE MISSING_SPENDGO_FROM_SPARKFLY_20250319 (
	SPENDGO_ID VARCHAR(100),
	FIRST_NAME VARCHAR(100),
	LAST_NAME VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	EMAIL VARCHAR(100),
	BIRTHDAY VARCHAR(100),
	ZIP_CODE VARCHAR(100),
	FAVORITE_STORE VARCHAR(100),
	LOYALTY_STATUS VARCHAR(25),
	SPENDGO_JOIN_DATE_UTC VARCHAR(50),
	SPENDGO_REGISTRATION_DATE_UTC VARCHAR(50),
	SPARKFLY_ID NUMBER(38,0),
	SPENDGO_ID_SPARKFLY VARCHAR(100),
	ENROLLMENT_ID_SPARKFLY NUMBER(38,0),
	EXTERNAL_ID_SPARKFLY VARCHAR(100),
	PHONE_NUMBER_SPARKFLY VARCHAR(100)
);
create or replace TABLE MISSING_SPENDGO_FROM_SPARKFLY_20250319_WITH_POINTS (
	SPENDGO_ID VARCHAR(100),
	FIRST_NAME VARCHAR(100),
	LAST_NAME VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	EMAIL VARCHAR(100),
	BIRTHDAY VARCHAR(100),
	ZIP_CODE VARCHAR(100),
	FAVORITE_STORE VARCHAR(100),
	LOYALTY_STATUS VARCHAR(25),
	SPENDGO_JOIN_DATE_UTC VARCHAR(50),
	SPENDGO_REGISTRATION_DATE_UTC VARCHAR(50),
	SPARKFLY_ID NUMBER(38,0),
	SPENDGO_ID_SPARKFLY VARCHAR(100),
	ENROLLMENT_ID_SPARKFLY NUMBER(38,0),
	EXTERNAL_ID_SPARKFLY VARCHAR(100),
	PHONE_NUMBER_SPARKFLY VARCHAR(100),
	AUG_SPENDGO_ID VARCHAR(100),
	AUG_POINTS NUMBER(38,0),
	SEPT_SPENDGO_ID VARCHAR(100),
	SEPT_POINTS NUMBER(38,0)
);
create or replace TABLE SPARKFLY_EXISTING_GUESTS (
	SPENDGO_ID NUMBER(38,0),
	PHONE_NUMBER NUMBER(38,0),
	EMAIL VARCHAR(16777216),
	POINTS_DELTA NUMBER(38,0)
);
create or replace TABLE SPARKFLY_EXISTING_GUESTS_FINAL (
	SPENDGO_ID NUMBER(38,0),
	PHONE_NUMBER NUMBER(38,0),
	EMAIL VARCHAR(16777216),
	POINTS_DELTA NUMBER(38,0)
);
create or replace TABLE SPARKFLY_NEW_GUESTS (
	SPENDGO_ID NUMBER(38,0),
	PHONE_NUMBER NUMBER(38,0),
	EMAIL VARCHAR(16777216),
	POINTS_BALANCE NUMBER(38,0)
);
create or replace TABLE SPARKFLY_NEW_GUESTS_CORRECTION (
	SPENDGO_ID NUMBER(38,0),
	PHONE_NUMBER NUMBER(38,0),
	EMAIL VARCHAR(16777216),
	POINTS_BALANCE NUMBER(38,0)
);
create or replace TABLE SPARKFLY_NEW_GUESTS_FINAL (
	SPENDGO_ID NUMBER(38,0),
	PHONE_NUMBER NUMBER(38,0),
	EMAIL VARCHAR(16777216),
	POINTS_BALANCE NUMBER(38,0)
);
create or replace TABLE SPARKFLY_SPENDGO_MEMBERS_20250317 (
	SPARKFLY_MEMBER_ID NUMBER(38,0),
	SPENDGO_GUEST_ID VARCHAR(100)
);
create or replace TABLE SPARKFLY_SPENDGO_MEMBERS_20250319 (
	SPARKFLY_ID NUMBER(38,0),
	SPENDGO_ID VARCHAR(100),
	ENROLLMENT_ID NUMBER(38,0),
	EXTERNAL_ID VARCHAR(100),
	PHONE_NUMBER VARCHAR(100)
);
create or replace TABLE SPENDGO_FILE_20240807 (
	SPENDGO_ID VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	EMAIL VARCHAR(100),
	EMAIL_OPT_IN_STATUS BOOLEAN,
	CURRENT_POINTS_BALANCE NUMBER(38,0),
	LOYALTY_STATUS VARCHAR(25),
	SPENDGO_JOIN_DATE_UTC VARCHAR(50)
);
create or replace TABLE SPENDGO_FILE_20240910 (
	SPENDGO_ID VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	EMAIL VARCHAR(100),
	EMAIL_OPT_IN_STATUS BOOLEAN,
	CURRENT_POINTS_BALANCE NUMBER(38,0),
	LOYALTY_STATUS VARCHAR(25),
	SPENDGO_JOIN_DATE_UTC VARCHAR(50)
);
create or replace TABLE SPENDGO_FILE_20240919 (
	SPENDGO_ID VARCHAR(100),
	LOYALTY_STATUS VARCHAR(25)
);
create or replace TABLE SPENDGO_FILE_20250319 (
	SPENDGO_ID VARCHAR(100),
	FIRST_NAME VARCHAR(100),
	LAST_NAME VARCHAR(100),
	PHONE_NUMBER VARCHAR(100),
	EMAIL VARCHAR(100),
	BIRTHDAY VARCHAR(100),
	ZIP_CODE VARCHAR(100),
	FAVORITE_STORE VARCHAR(100),
	LOYALTY_STATUS VARCHAR(25),
	SPENDGO_JOIN_DATE_UTC VARCHAR(50),
	SPENDGO_REGISTRATION_DATE_UTC VARCHAR(50)
);
create or replace view BRAZE_STAGING(
	UPDATED_AT,
	EXTERNAL_ID,
	FIRST_NAME,
	LAST_NAME,
	PHONE,
	EMAIL,
	DOB,
	SOURCE,
	EMAIL_SUBSCRIBE,
	SUBSCRIBE,
	FAVORITE_RESTAURANT_NUMBER,
	COUNTRY,
	RESTAURANT_NUMBER,
	RECENCY
) as
WITH BASE AS (
        SELECT
            rd.customer_key,
            rd.First_Name,
            rd.Last_Name,
            rd.Phone,
            rd.email,
            rd.birthday,
            dc.source,
            dc.spendgo_guest_id,
            dc.IN_MARKETING_EMAIL,
            dc.IN_MARKETING_PUSH,
            dc.favorite_restaurant_number,
            cm.loyalty_status,
            cm.registered
        FROM
            COSTAVIDA_DB_PROD.RESTRICTED.DIM_CUSTOMER_PII rd
        INNER JOIN COSTAVIDA_DB_PROD.STAGE.DIM_CUSTOMER_DEDUPE_VW dc ON rd.customer_key = dc.customer_key
        LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_MEMBER_CURRENT_VW cm ON (dc.spendgo_guest_id = cm.spendgo_guest_id)
        WHERE
            dc.spendgo_guest_id <> 'UNKNOWN'
            AND dc.spendgo_guest_id IS NOT NULL
            --AND (dc.In_Marketing_Email = True OR dc.in_marketing_push = True)
            AND cm.registered
)
SELECT
    CURRENT_TIMESTAMP AS UPDATED_AT,
    fc.spendgo_guest_id AS External_Id,
    fc.First_Name,
    fc.Last_Name,
    case ca.country 
        when 'US' then fc.Phone
        when 'CA' then '+1'||fc.Phone
        else fc.Phone
    end as phone,
    fc.email,
    CASE
        WHEN TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY') IS NULL THEN NULL
        ELSE TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY')
    END AS dob,
    fc.source,
    CASE
        WHEN fc.IN_MARKETING_EMAIL = True AND email.EMAIL_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS email_subscribe,
    CASE
        WHEN fc.IN_MARKETING_PUSH = True AND sms.SMS_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS subscribe,
    fc.favorite_restaurant_number,
    CASE
        WHEN fc.favorite_restaurant_number = '0000' THEN NULL
        ELSE ca.country
    END AS country,
    ca.restaurant_number,
    COALESCE(recency.RECENCY,'No Visit Yet') as RECENCY
FROM BASE fc
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW ca ON fc.favorite_restaurant_number = ca.restaurant_number
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_SMS_CLEANUP_1 sms ON (fc.spendgo_guest_id = sms.spendgo_guest_id)
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_EMAIL_CLEANUP_1 email ON (fc.spendgo_guest_id = email.spendgo_guest_id)
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.RECENCY_VW recency ON (fc.spendgo_guest_id = recency.spendgo_guest_id)
WHERE (fc.favorite_restaurant_number in (SELECT restaurant_number FROM COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW) or fc.favorite_restaurant_number is null);
create or replace view BRAZE_STAGING_FINAL(
	UPDATED_AT,
	EXTERNAL_ID,
	FIRST_NAME,
	LAST_NAME,
	PHONE,
	EMAIL,
	DOB,
	SOURCE,
	EMAIL_SUBSCRIBE,
	SUBSCRIBE,
	FAVORITE_RESTAURANT_NUMBER,
	COUNTRY,
	RESTAURANT_NUMBER,
	RECENCY
) as
WITH BASE AS (
        SELECT
            rd.customer_key,
            cm.First_Name,
            cm.Last_Name,
            cm.Phone,
            cm.email,
            rd.birthday,
            dc.source,
            cm.spendgo_guest_id,
            dc.IN_MARKETING_EMAIL,
            dc.IN_MARKETING_PUSH,
            dc.favorite_restaurant_number,
            cm.loyalty_status,
            cm.registered
        FROM 
            COSTAVIDA_DB_PROD.STAGE.SPENDGO_MEMBER_CURRENT_FINAL_VW cm
        LEFT JOIN COSTAVIDA_DB_PROD.STAGE.DIM_CUSTOMER_DEDUPE_VW dc ON (cm.spendgo_guest_id = try_cast(dc.spendgo_guest_id AS NUMBER))  
        LEFT JOIN COSTAVIDA_DB_PROD.RESTRICTED.DIM_CUSTOMER_PII rd ON dc.customer_key = rd.customer_key
 /*
        WHERE
            dc.spendgo_guest_id <> 'UNKNOWN'
            AND dc.spendgo_guest_id IS NOT NULL
            --AND (dc.In_Marketing_Email = True OR dc.in_marketing_push = True)
            AND cm.registered
*/
)
SELECT
    CURRENT_TIMESTAMP AS UPDATED_AT,
    fc.spendgo_guest_id AS External_Id,
    fc.First_Name,
    fc.Last_Name,
    case ca.country 
        when 'US' then fc.Phone::integer::string
        when 'CA' then '+1'||fc.Phone::integer::string
        else fc.Phone::integer::string
    end as phone,
    fc.email,
    CASE
        WHEN TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY') IS NULL THEN NULL
        ELSE TRY_TO_DATE(TO_VARCHAR(fc.birthday, 'MM-DD') || '-1900', 'MM-DD-YYYY')
    END AS dob,
    fc.source,
    CASE
        WHEN fc.IN_MARKETING_EMAIL = True AND email.EMAIL_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS email_subscribe,
    CASE
        WHEN fc.IN_MARKETING_PUSH = True AND sms.SMS_PREFERENCE IS NULL THEN 'opted_in'
        ELSE 'unsubscribed'
    END AS subscribe,
    fc.favorite_restaurant_number,
    CASE
        WHEN fc.favorite_restaurant_number = '0000' THEN NULL
        ELSE ca.country
    END AS country,
    ca.restaurant_number,
    COALESCE(recency.RECENCY,'No Visit Yet') as RECENCY
FROM BASE fc
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW ca ON fc.favorite_restaurant_number = ca.restaurant_number
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_SMS_CLEANUP_1 sms ON (try_cast(fc.spendgo_guest_id as NUMBER) = try_cast(sms.spendgo_guest_id as NUMBER))
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.SPENDGO_EMAIL_CLEANUP_1 email ON (try_cast(fc.spendgo_guest_id as NUMBER) = try_cast(email.spendgo_guest_id as NUMBER))
LEFT JOIN COSTAVIDA_DB_PROD.STAGE.RECENCY_VW recency ON (try_cast(fc.spendgo_guest_id as NUMBER) = try_cast(recency.spendgo_guest_id as NUMBER))
--WHERE (fc.favorite_restaurant_number in (SELECT restaurant_number FROM COSTAVIDA_DB_PROD.STAGE.DIM_RESTAURANT_CURRENT_VW) or fc.favorite_restaurant_number is null);
;
CREATE OR REPLACE FUNCTION "BRAZE_SMS_STATUS"("SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
   SELECT 
        case 
            when country is null then ''unsubscribed'' 
            when country is not null and sms_status = ''opted_in'' then ''subscribed''
            when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
            else ''unsubscribed''
        end as status
';
CREATE OR REPLACE FUNCTION "BRAZE_SUBSCRIPTION_GROUPS"("EMAIL_STATUS" VARCHAR(16777216), "SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS ARRAY
LANGUAGE SQL
AS '
   SELECT 
      array_construct(
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''70b11318-7363-459d-b11f-eee3326e75de''
                    when country = ''CA'' then ''a9b4c155-a919-4279-ad03-3ba8abef4c7f''
                    when country is null then ''70b11318-7363-459d-b11f-eee3326e75de''
                    else ''70b11318-7363-459d-b11f-eee3326e75de'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and sms_status = ''opted_in'' then ''subscribed''
                    when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          ),
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''da996523-fa1c-4427-b043-5d5c62281b78''
                    when country = ''CA'' then ''2fa6c5dd-11f0-4a6b-b541-be5f04507611''
                    when country is null then ''da996523-fa1c-4427-b043-5d5c62281b78''
                    else ''da996523-fa1c-4427-b043-5d5c62281b78'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and email_status = ''opted_in'' then ''subscribed''
                    when country is not null and email_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          )
      ) as subscription_groups
';
CREATE OR REPLACE FUNCTION "BRAZE_SUBSCRIPTION_GROUPS_SMS_ONLY"("SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS ARRAY
LANGUAGE SQL
AS '
   SELECT 
      array_construct(
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''70b11318-7363-459d-b11f-eee3326e75de''
                    when country = ''CA'' then ''a9b4c155-a919-4279-ad03-3ba8abef4c7f''
                    when country is null then ''70b11318-7363-459d-b11f-eee3326e75de''
                    else ''70b11318-7363-459d-b11f-eee3326e75de'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and sms_status = ''opted_in'' then ''subscribed''
                    when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          )
      ) as subscription_groups
';
