-- FUNCTIONS: BRAZE_SUBSCRIPTION_GROUPS_SMS_ONLY
-- Generated on: 2025-06-05 11:29:31
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE FUNCTION "BRAZE_SUBSCRIPTION_GROUPS_SMS_ONLY"("SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS ARRAY
LANGUAGE SQL
AS '
   SELECT 
      array_construct(
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''70b11318-7363-459d-b11f-eee3326e75de''
                    when country = ''CA'' then ''a9b4c155-a919-4279-ad03-3ba8abef4c7f''
                    when country is null then ''70b11318-7363-459d-b11f-eee3326e75de''
                    else ''70b11318-7363-459d-b11f-eee3326e75de'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and sms_status = ''opted_in'' then ''subscribed''
                    when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          )
      ) as subscription_groups
';
