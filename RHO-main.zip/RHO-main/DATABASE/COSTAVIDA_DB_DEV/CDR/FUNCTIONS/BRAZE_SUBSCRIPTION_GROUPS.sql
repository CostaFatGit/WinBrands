-- FUNCTIONS: BRAZE_SUBSCRIPTION_GROUPS
-- Generated on: 2025-06-05 11:29:31
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE FUNCTION "BRAZE_SUBSCRIPTION_GROUPS"("EMAIL_STATUS" VARCHAR(16777216), "SMS_STATUS" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS ARRAY
LANGUAGE SQL
AS '
   SELECT 
      array_construct(
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''70b11318-7363-459d-b11f-eee3326e75de''
                    when country = ''CA'' then ''a9b4c155-a919-4279-ad03-3ba8abef4c7f''
                    when country is null then ''70b11318-7363-459d-b11f-eee3326e75de''
                    else ''70b11318-7363-459d-b11f-eee3326e75de'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and sms_status = ''opted_in'' then ''subscribed''
                    when country is not null and sms_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          ),
          object_construct(
            ''subscription_group_id'', 
                case 
                    when country = ''US'' then ''da996523-fa1c-4427-b043-5d5c62281b78''
                    when country = ''CA'' then ''2fa6c5dd-11f0-4a6b-b541-be5f04507611''
                    when country is null then ''da996523-fa1c-4427-b043-5d5c62281b78''
                    else ''da996523-fa1c-4427-b043-5d5c62281b78'' 
                end,
            ''subscription_state'',
                case 
                    when country is null then ''unsubscribed'' 
                    when country is not null and email_status = ''opted_in'' then ''subscribed''
                    when country is not null and email_status = ''unsubscribed'' then ''unsubscribed''
                    else ''unsubscribed''
                end
          )
      ) as subscription_groups
';
