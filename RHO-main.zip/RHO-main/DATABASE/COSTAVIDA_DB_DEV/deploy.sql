-- Master Deployment Script
-- Generated on: 2025-06-05 11:29:45
-- Database: COSTAVIDA_DB_DEV

-- Deploy in the following order to respect dependencies:

-- 1. Schemas
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/SCHEMAS/*.sql;

-- 2. Sequences
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/SEQUENCES/*.sql;

-- 3. Tables
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/TABLES/*.sql;

-- 4. Views
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/VIEWS/*.sql;

-- 5. Functions
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/FUNCTIONS/*.sql;

-- 6. Procedures
EXECUTE IMMEDIATE FROM @my_github_repo/branches/main/COSTAVIDA_DB_DEV/*/PROCEDURES/*.sql;
