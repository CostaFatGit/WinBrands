-- PROCEDURES: SP_GET_QUALTRICS_SURVEY_CONFIG
-- Generated on: 2025-06-05 11:29:35
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_GET_QUALTRICS_SURVEY_CONFIG"()
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
      result_set RESULTSET;
      seq_key INT;

BEGIN

  SELECT 
    RAW.SEQ_QUALTRICS_SURVEY.NEXTVAL 
  INTO 
    :seq_key;
    
    result_set := (
        SELECT 
          Q.SURVEY_ID
         ,Q.FRIENDLY_NAME
         ,Q.API_TOKEN
         ,Q.CONTINUATION_TOKEN
         ,Q.FILE_FORMAT
         ,Q.RESPONSE_URL
         ,Q.RESPONSE_ENABLED_DATETIME
         --Im doing the TRUE/FALSE CASE statements just because its easier to deal with that comparison here 
         ,CASE
            WHEN Q.RESPONSE_ENABLED_DATETIME <= CURRENT_TIMESTAMP() THEN TRUE ELSE FALSE
          END AS RESPONSE_ENABLED
         ,Q.DEFINITION_URL
         ,Q.DEFINITION_ENABLED_DATETIME
         ,CASE
            WHEN Q.DEFINITION_ENABLED_DATETIME <= CURRENT_TIMESTAMP() THEN TRUE ELSE FALSE
          END AS DEFINITION_ENABLED
         ,Q.CREATED_DATETIME
         ,:seq_key AS RUN_ID
        FROM 
          ADMIN.QUALTRICS_SURVEY_CONFIG Q
        --There is no RESPONSE_ENABLED_DATETIME <= CURRENT_TIMESTAMP() check in the WHERE clause.
        --We return all configs and let the pipeline determine which ones to do
        --Not have we usually do stuff, but since this pipeline does DEFINITIONS and RESPONSES, it makes sense
    );


    RETURN TABLE(result_set);

END';
