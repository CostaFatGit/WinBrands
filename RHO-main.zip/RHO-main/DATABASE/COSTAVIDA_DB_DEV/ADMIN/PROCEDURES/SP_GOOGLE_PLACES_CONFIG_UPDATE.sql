-- PROCEDURES: SP_GOOGLE_PLACES_CONFIG_UPDATE
-- Generated on: 2025-06-05 11:29:36
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_GOOGLE_PLACES_CONFIG_UPDATE"("RESTAURANT_KEY" NUMBER(38,0), "PLACE_ID" VARCHAR(16777216), "ERROR_MESSAGE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN
    -- Update the table, using IFNULL to retain current values for columns if the input is NULL
    UPDATE 
      ADMIN.GOOGLE_PLACES_CONFIG
    SET 
      PLACE_ID = IFNULL(:PLACE_ID, PLACE_ID),  -- Update PLACE_ID if provided, otherwise keep the current value
      ERROR_MESSAGE = IFNULL(:ERROR_MESSAGE, ERROR_MESSAGE)  -- Update ERROR_MESSAGE if provided, otherwise keep the current value
    WHERE 
      RESTAURANT_KEY = :RESTAURANT_KEY;

    --PUBLIC.DIM_RESTAURANT.GOOGLE_PLACE_ID was added later.  This is a way to keep it updated.
    UPDATE 
      PUBLIC.DIM_RESTAURANT
    SET 
      GOOGLE_PLACE_ID = IFNULL(:PLACE_ID, GOOGLE_PLACE_ID)  -- Update GOOGLE_PLACE_ID if provided, otherwise keep the current value
    WHERE 
      RESTAURANT_KEY = :RESTAURANT_KEY;

    RETURN ''Update successful'';
END;
';
