-- VIEWS: VIEW_PROF_LOSS
-- Generated on: 2025-06-05 11:29:28
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_PROF_LOSS(
	RESTAURANT_KEY,
	FRANCHISE_GROUP,
	RESTAURANT_NAME,
	DATE,
	MONTH,
	YEAR,
	LABELNAME,
	AMOUNT,
	SORT_ORDER
) as
(
SELECT
  R.RESTAURANT_KEY
 ,R.FRANCHISE_GROUP
 ,R.RESTAURANT_NAME
 ,D.DATE
 ,D.MONTH
 ,D.YEAR
 ,DT.LABELNAME
 ,DT.AMOUNT
 ,L.SORT_ORDER
FROM
(
    SELECT 
      R.RESTAURANT_KEY,
      R.DATE_KEY,
      F.key AS LABELNAME,
      F.value::NUMBER(10,2) AS AMOUNT
    FROM 
    (    
      SELECT 
        RESTAURANT_KEY,
        DATE_KEY,
        OBJECT_CONSTRUCT
        (
            'Catering & Event Sales', CATERING_EVENT_SALES,
            'Delivery Sales', DELIVERY_SALES,
            'Dine In Sales', DINE_IN_SALES,
            'Drive Thru Sales', DRIVE_THRU_SALES,
            'Online Sales', ONLINE_SALES,
            'Phone Order Sales', PHONE_ORDER_SALES,
            'To Go Sales', TO_GO_SALES,
            'Total Sales', TOTAL_SALES,
            'Discounts', DISCOUNTS,
            'Net Sales', NET_SALES,
            'Beverage COGS', BEVERAGE_COGS,
            'Food COGS', FOOD_COGS,
            'Paper COGS', PAPER_COGS,
            'Total COGS', TOTAL_COGS,
            'Gross Profit', GROSS_PROFIT,
            'Local Advertising & Marketing', LOCAL_ADVERTISING_MARKETING,
            'MAF', MAF,
            'Total Advertising & Marketing', TOTAL_ADVERTISING_MARKETING,
            'Incentives', INCENTIVES,
            'Insurance Benefits', INSURANCE_BENEFITS,
            'Taxes', TAXES,
            'Total Employee Benefits', TOTAL_EMPLOYEE_BENEFITS,
            'R&M-Building', R_M_BUILDING,
            'R&M-Computers', R_M_COMPUTERS,
            'R&M-Equipment', R_M_EQUIPMENT,
            'Total Repairs & Maintenance', TOTAL_REPAIRS_MAINTENANCE,
            'Bonuses', BONUSES,
            'Hourly', HOURLY,
            'Overtime', OVERTIME,
            'Salaried', SALARIED,
            'Misc.', MISC,
            'Total Salaries & Wages', TOTAL_SALARIES_WAGES,
            'Janitorial Supplies', JANITORIAL_SUPPLIES,
            'Linen Supplies', LINEN_SUPPLIES,
            'Office Supplies', OFFICE_SUPPLIES,
            'Operational Supplies', OPERATIONAL_SUPPLIES,
            'Smallwares', SMALLWARES,
            'Uniforms', UNIFORMS,
            'Total Supplies', TOTAL_SUPPLIES,
            'Travel & Entertainment', TRAVEL_ENTERTAINMENT,
            'Over/Short', OVER_SHORT,
            'Total Controllable Expenses', TOTAL_CONTROLLABLE_EXPENSES,
            'Bank Service Charges', BANK_SERVICE_CHARGES,
            'Credit Card Processing Fees', CREDIT_CARD_PROCESSING_FEES,
            'Depreciation & Amortization Expense', DEPRECIATION_AMORTIZATION_EXPENSE,
            'Dues & Subscriptions', DUES_SUBSCRIPTIONS,
            'Liability Insurance', LIABILITY_INSURANCE,
            'Interest Expense', INTEREST_EXPENSE,
            'Licenses', LICENSES,
            'Management Fees', MANAGEMENT_FEES,
            'Royalties', ROYALTIES,
            'Accounting Fees', ACCOUNTING_FEES,
            'Consulting Fees', CONSULTING_FEES,
            'Delivery Fees', DELIVERY_FEES,
            'Legal Fees', LEGAL_FEES,
            'Pest Control', PEST_CONTROL,
            'Security Fees', SECURITY_FEES,
            'Total Professional Fees', TOTAL_PROFESSIONAL_FEES,
            'Property Taxes', PROPERTY_TAXES,
            'Sales Tax Discounts', SALES_TAX_DISCOUNTS,
            'Rent', RENT,
            'Cam', CAM,
            'Total Rent & CAM', TOTAL_RENT_CAM,
            'Equipment Rentals', EQUIPMENT_RENTALS,
            'TV & Music', TV_MUSIC,
            'Electrical Power', ELECTRICAL_POWER,
            'Garbage Collection', GARBAGE_COLLECTION,
            'Natural Gas', NATURAL_GAS,
            'Telephone & Internet', TELEPHONE_INTERNET,
            'Water & Sewer', WATER_SEWER,
            'Total Utilities', TOTAL_UTILITIES,
            'Total Other Restaurant Expense', TOTAL_OTHER_RESTAURANT_EXPENSE,
            'Total Expense', TOTAL_EXPENSE,
            'Net Income', NET_INCOME,
            'EBITDA', EBITDA
        ) AS JSON_DATA
      FROM 
        PUBLIC.FACT_PROF_LOSS
    ) R,
    LATERAL FLATTEN
    (
      input => R.JSON_DATA
    ) F
) DT
JOIN
  PUBLIC.DIM_RESTAURANT R ON DT.RESTAURANT_KEY = R.RESTAURANT_KEY AND R.RECORD_IS_CURRENT = TRUE
JOIN
  PUBLIC.DIM_DATE D ON DT.DATE_KEY = D.DATE_KEY AND D.RECORD_IS_CURRENT = TRUE
JOIN
  PUBLIC.DIM_LABEL L ON DT.LABELNAME = L.LABELNAME AND L.RECORD_IS_CURRENT = TRUE
);
