-- VIEWS: VIEW_LOAD_STATUS
-- Generated on: 2025-06-05 11:29:27
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_LOAD_STATUS(
	RESTAURANT_KEY,
	RESTAURANT_NUMBER,
	RESTAURANT_NAME,
	STATUS,
	RECORDS_LOADED,
	FIRST_SALE,
	LATEST_SALE,
	DAYS_LOADED,
	DAYS_REMAINING,
	CLOSED_DATE,
	PCT_COMPLETE
) as
  select 
    r.restaurant_key,
    r.restaurant_number,
    r.restaurant_name, 
    r.status,
    count(*) as "RECORDS_LOADED",
    date_trunc('DAY',to_date(min(s.order_created_time))) as "FIRST_SALE", 
    date_trunc('DAY',to_date(max(s.order_modified_time))) as "LATEST_SALE", 
    datediff(day,"FIRST_SALE"::timestamp,"LATEST_SALE"::timestamp) as "DAYS_LOADED", 
    iff(r.closed_date is null, datediff(day,"LATEST_SALE"::timestamp,current_timestamp), datediff(day,"LATEST_SALE"::timestamp,r.closed_date::timestamp)) as "DAYS_REMAINING", 
    r.closed_date,
    iff("DAYS_REMAINING" = 0 OR latest_sale::date >= r.closed_date::date, 100, round("DAYS_LOADED" / ("DAYS_LOADED" + "DAYS_REMAINING") * 100,3)) as "PCT_COMPLETE"
  from FACT_SALES as s
  left join dim_restaurant r on r.restaurant_key = s.restaurant_key
  group by r.restaurant_key, restaurant_number, r.restaurant_name, r.status, r.closed_date order by restaurant_name;
