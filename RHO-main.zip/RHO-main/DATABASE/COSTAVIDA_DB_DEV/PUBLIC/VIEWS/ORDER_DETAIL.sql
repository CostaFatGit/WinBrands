-- VIEWS: ORDER_DETAIL
-- Generated on: 2025-06-05 11:29:25
-- Database: COSTAVIDA_DB_DEV

create or replace view ORDER_DETAIL(
	RESTAURANT_NUMBER,
	DATE,
	ORDER_NUMBER,
	POS_ORDER_ID,
	POS_ORDERITEM_ID,
	TRANSACTION_CATEGORY,
	TRANSACTION_NAME,
	PRODUCT_CATEGORY,
	PRODUCT_NAME,
	PRODUCT_NUMBER,
	QUANTITY,
	PRICE,
	TAX
) as
  select
    r.restaurant_number,
    d.date,
    s.order_number,
    s.pos_order_id,
    s.pos_orderitem_id,
    tt.transaction_category,
    tt.transaction_name,
    p.product_category,
    p.product_name,
    p.product_number,
    s.quantity,
    s.price,
    s.tax
  from fact_sales s
    left join dim_restaurant r on r.restaurant_key=s.restaurant_key
    left join dim_product p on p.product_key=s.product_key
    left join dim_transaction_type tt on tt.transaction_type_key=s.transaction_type_key
    left join dim_date d on d.date_key=s.date_key
  order by r.restaurant_number, d.date, s.order_number, s.pos_orderitem_id, price desc
;
