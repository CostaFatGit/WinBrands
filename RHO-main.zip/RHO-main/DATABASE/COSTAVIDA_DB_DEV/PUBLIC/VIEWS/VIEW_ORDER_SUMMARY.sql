-- VIEWS: VIEW_ORDER_SUMMARY
-- Generated on: 2025-06-05 11:29:27
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_ORDER_SUMMARY(
	RESTAURANT_NUMBER,
	DATE,
	HOUR,
	DAYPART,
	DINING_OPTION,
	POS_ORDER_ID,
	ORDER_NUMBER,
	POS_SYSTEM,
	POS_DURATION,
	GROSS_SALES,
	ENTERED_DISCOUNTS,
	APPLIED_DISCOUNTS,
	ITEM_REFUNDS,
	PAYMENT_REFUNDS,
	SERVICE_CHARGES,
	NET_SALES,
	GRATUITIES,
	DEFERRED_SALES,
	NET_TAX
) as
  select restaurant_number, date, hour, daypart, dining_option, pos_order_id, order_number, s.pos_system, datediff(millisecond, order_created_time, order_modified_time)/1000 as pos_duration,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='GROSS SALES') as gross_sales,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='DISCOUNTS' and tt1.pos_transaction_name<>'Excess Discount') as entered_discounts,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='DISCOUNTS') as applied_discounts,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='REFUNDS') as item_refunds,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='PAYMENTS' and tt1.pos_transaction_name='Payment Refund') as payment_refunds,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='SERVICE CHARGES') as service_charges,
    gross_sales + service_charges + applied_discounts + item_refunds as net_sales,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='GRATUITIES') as gratuities,
    (select zeroifnull(sum(price)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date and tt1.pos_transaction_category='DEFERRED SALES') as deferred_sales,
    (select zeroifnull(sum(tax)) from fact_sales s1 left join dim_transaction_type tt1 on tt1.transaction_type_key=s1.transaction_type_key left join dim_date d1 on d1.date_key=s1.date_key where s1.pos_order_id=s.pos_order_id and s1.order_number=s.order_number and d1.date=d.date) as net_tax
    -- iff(gross_sales > discounts, 0, 0 - gross_sales + discounts) as discount_adjustments
  from 
    public.FACT_SALES s
    left join public.dim_transaction_type tt on tt.transaction_type_key=s.transaction_type_key
    left join public.dim_product p on p.product_key=s.product_key
    left join public.dim_date d on d.date_key=s.date_key
    left join public.dim_time t on t.time_key=s.time_key
    left join public.dim_restaurant r on r.restaurant_key=s.restaurant_key
    left join public.dim_behavior b on b.behavior_key=s.behavior_key
  where 
    r.status = 'Active'
  --   year(d.date)=2022 and month(d.date)=7 and day(d.date)=4
  --   and r.restaurant_number='0026' and r.record_is_current=true
  group by (restaurant_number, date, hour, daypart, dining_option, pos_order_id, order_number, s.pos_system, s.order_created_time, s.order_modified_time) 
  order by restaurant_number, date, hour, daypart, dining_option, order_number, pos_order_id, s.pos_system, s.order_created_time, s.order_modified_time
  ;
