-- VIEWS: VIEW_GWAP
-- Generated on: 2025-06-05 11:29:27
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_GWAP(
	DATE,
	RESTAURANT_NAME,
	PROBLEM_COUNT,
	ORDER_COUNT
) as
WITH t1 AS (
-- Provides all feedback information
SELECT a.ORDER_DATE,
a.source_feedback_id AS source_id,
TO_DATE(a.feedback_response_time) AS response_date,
b.feedback_category,
b.FEEDBACK_SUBCATEGORY,
b.FEEDBACK_SOURCE_ITEM_OPTION AS score,
b.FEEDBACK_ITEM,
c.RESTAURANT_NUMBER,
c.RESTAURANT_NAME,
c.FRANCHISE_GROUP,
c.restaurant_email,
c.CITY,
c.STATE,
c.COUNTRY,
c.STATUS,
c.HAS_DRIVETHRU,
c.IS_CORPORATE,
D.DAY_OF_WEEK,
D."MONTH",
D.QUARTER_NUMBER,
D."YEAR"
FROM FACT_FEEDBACK AS a
INNER JOIN DIM_FEEDBACK_TYPE AS b
ON a.FEEDBACK_TYPE_KEY = b.FEEDBACK_TYPE_KEY
INNER JOIN DIM_RESTAURANT AS c
ON a.RESTAURANT_KEY = c.RESTAURANT_KEY 
INNER JOIN DIM_DATE AS d
ON a.ORDER_DATE_KEY = D.DATE_KEY
WHERE b.FEEDBACK_SOURCE_ITEM_OPTION NOT IN ('N/A', 'Yes', 'No')
AND b.FEEDBACK_CATEGORY NOT IN ('Contact Web Survey', 'Contact Restaurant Survey')
AND b.FEEDBACK_ITEM IN ('Likelihood to Recommend')
ORDER BY 1 DESC
),
t2 AS (
-- Makes another column with comment to contact
SELECT a.SOURCE_FEEDBACK_ID,
	c.restaurant_name,
       TO_DATE(a.feedback_response_time) AS response_date,
       b.FEEDBACK_SOURCE_ITEM_OPTION AS score_comment,
       b.FEEDBACK_ITEM
FROM FACT_FEEDBACK AS a
INNER JOIN DIM_FEEDBACK_TYPE AS b
ON a.FEEDBACK_TYPE_KEY = b.FEEDBACK_TYPE_KEY
INNER JOIN DIM_RESTAURANT AS c
ON a.restaurant_key = c.restaurant_key
WHERE b.FEEDBACK_ITEM = 'Customer Contact'
),
t3 AS (
--Joints both t1 and t2 to add score_comment as a column
SELECT a.source_id,
a.restaurant_name,
a.response_date,
a.score,
COALESCE (b.score_comment, 'No Comment') AS score_comment
FROM t1 AS a
INNER join t2 AS b
ON a.source_id = b.SOURCE_FEEDBACK_ID
WHERE a.response_Date >= DATEADD(DAY, -1100, CURRENT_TIMESTAMP())
ORDER BY 2 DESC
),
t4 as(
--Calculates problem count using the subquery's logic
SELECT response_date,
restaurant_name,
sum(problem_count) AS problem_count
FROM (
SELECT response_date,
restaurant_name,
CASE WHEN score <= 6 THEN 1
	WHEN score IN (7,8) AND score_comment IN ('Yes, I prefer to communicate via email', 'Yes, I prefer a phone call') THEN 1
	WHEN score IN (7,8) AND score_comment IN ('No, please do not contact me', 'No Comment') THEN 0
	WHEN score IN (9,10) THEN 0
	END AS problem_count
FROM t3
)
GROUP BY 1,2
ORDER BY 1
),
t5 AS (
--provides order count by restaurant
SELECT date,
restaurant_name,
count(DISTINCT unique_id) AS order_count
FROM (
SELECT d."DATE" AS date,
b.restaurant_name,
a.pos_order_id AS unique_id,
sum(a.PRICE) AS total_sales
FROM FACT_SALES AS a
INNER JOIN DIM_RESTAURANT AS b
ON a.RESTAURANT_KEY = b.RESTAURANT_KEY 
INNER JOIN DIM_TRANSACTION_TYPE AS c
ON a.TRANSACTION_TYPE_KEY = c.TRANSACTION_TYPE_KEY 
INNER JOIN DIM_DATE AS D
ON a.date_key = D.date_key
WHERE c.TRANSACTION_NAME NOT IN ('Gift Card')
AND c.transaction_Category NOT IN ('DEFERRED SALES')
AND b.RECORD_IS_CURRENT = 'True' AND b.STATUS = 'Active'
GROUP BY 1,2,3
ORDER BY 2
)
WHERE date >= DATEADD(DAY, -1100, CURRENT_TIMESTAMP())
AND total_sales != 0
GROUP BY 1,2
ORDER BY 2
)
SELECT a.date,
a.restaurant_name,
COALESCE(b.problem_count, 0) AS problem_count,
a.order_count
FROM t5 AS a
left join t4 AS b
ON a.restaurant_name = b.restaurant_name AND a.date = b.response_date
WHERE a.date >= DATEADD(DAY, -1100, CURRENT_TIMESTAMP())
ORDER BY 1, 2 DESC;
