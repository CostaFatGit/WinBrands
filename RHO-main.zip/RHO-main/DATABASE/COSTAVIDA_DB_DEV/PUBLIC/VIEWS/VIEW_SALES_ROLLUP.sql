-- VIEWS: VIEW_SALES_ROLLUP
-- Generated on: 2025-06-05 11:29:28
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_SALES_ROLLUP(
	RESTAURANT_NUMBER,
	YEAR,
	MONTH,
	DATE,
	ORDER_COUNT,
	GROSS_SALES,
	ENTERED_DISCOUNTS,
	APPLIED_DISCOUNTS,
	ITEM_REFUNDS,
	PAYMENT_REFUNDS,
	SVC_CHARGES,
	NET_SALES,
	GRATUITIES,
	DEFERRED_SALES,
	NET_TAX
) as
select restaurant_number, year(date) as year, month(date) as month, date,
  count(*) as order_count,
  sum(gross_sales) as gross_sales, 
  sum(entered_discounts) as entered_discounts, 
  sum(applied_discounts) as applied_discounts, 
  sum(item_refunds) as item_refunds, 
  sum(payment_refunds) as payment_refunds, 
  sum(service_charges) as svc_charges, 
  sum(net_sales) as net_sales, 
  sum(gratuities) as gratuities, 
  sum(deferred_sales) as deferred_sales, 
  sum(net_tax) as net_tax
from public.order_summary
group by rollup (restaurant_number, year, month, date)
order by restaurant_number, year, month, date;
