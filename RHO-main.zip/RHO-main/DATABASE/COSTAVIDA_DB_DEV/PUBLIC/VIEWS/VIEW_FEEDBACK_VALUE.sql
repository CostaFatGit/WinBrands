-- VIEWS: VIEW_FEEDBACK_VALUE
-- Generated on: 2025-06-05 11:29:27
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_FEEDBACK_VALUE(
	SCORE,
	IS_CURRENT_DAY,
	IS_CURRENT_WEEK,
	IS_CURRENT_MONTH,
	IS_CURRENT_YEAR,
	IS_PREVIOUS_DAY,
	IS_PREVIOUS_WEEK,
	IS_PREVIOUS_MONTH,
	IS_PREVIOUS_YEAR,
	IS_CORPORATE,
	RESTAURANT_NUMBER,
	RESTAURANT_NAME,
	CITY,
	STATE,
	COUNTRY,
	HAS_DRIVETHRU,
	FRANCHISE_GROUP,
	FRANCHISE_OWNER,
	BUSINESS_ENTITY,
	ORDER_DATE,
	ORDER_DAY_OF_WEEK_NUMBER,
	ORDER_DAY_OF_WEEK,
	ORDER_WEEK_NUMBER,
	ORDER_MONTH_NUMBER,
	ORDER_MONTH,
	ORDER_QUARTER_NUMBER,
	ORDER_YEAR,
	ORDER_HOUR,
	ORDER_DAYPART
) as select
  try_cast(ft.FEEDBACK_SOURCE_ITEM_OPTION as number) as score,
  iff(rd.date = current_date(), true, false) as is_current_day,
  iff(rd.year = year(current_date()) and rd.week_number = week(current_date()), true, false) as is_current_week,
  iff(rd.year = year(current_date()) and rd.month_number = month(current_date()), true, false) as is_current_month,
  iff(rd.year = year(current_date()), true, false) as is_current_year,
  iff(rd.date = dateadd(day, -1, current_date()), true, false) as is_previous_day,
  iff(rd.year = year(dateadd(week,-1,current_date())) and rd.week_number = week(dateadd(week,-1,current_date())), true, false) as is_previous_week,
  iff(rd.year = year(dateadd(month,-1,current_date())) and rd.month_number = month(dateadd(month,-1,current_date())), true, false) as is_previous_month,
  iff(rd.year = year(dateadd(year,-1,current_date())), true, false) as is_previous_year,
  r.is_corporate,
  r.restaurant_number,
  r.restaurant_name,
  r.city,
  r.state,
  r.country,
  r.has_drivethru,
  r.franchise_group,
  r.franchise_owner,
  r.business_entity,
  f.order_date,
  od.day_of_week_number as order_day_of_week_number,
  od.day_of_week as order_day_of_week,
  od.week_number as order_week_number,
  od.month_number as order_month_number,
  od.month as order_month,
  od.quarter_number as order_quarter_number,
  od.year as order_year,
  ot.hour as order_hour,
  ot.daypart as order_daypart
from
  fact_feedback f
  inner join public.dim_feedback_type ft on ft.feedback_type_key=f.feedback_type_key
  inner join public.dim_date rd on rd.date_key=f.response_date_key
  inner join public.dim_date od on od.date_key=f.order_date_key
  inner join public.dim_time ot on ot.time_key=f.order_time_key
  inner join public.dim_restaurant r on r.restaurant_key=f.restaurant_key
where
  ft.feedback_category='CUSTOMER SURVEY'
  and ft.feedback_item='Value'
;
