-- VIEWS: FEEDBACK_DETAIL
-- Generated on: 2025-06-05 11:29:25
-- Database: COSTAVIDA_DB_DEV

create or replace view FEEDBACK_DETAIL(
	SOURCE_FEEDBACK_ID,
	FEEDBACK_CREATED_TIME,
	FEEDBACK_RESPONSE_TIME,
	ORDER_DATE,
	HOUR,
	DAYPART,
	ORDER_NUMBER,
	RESTAURANT_NUMBER,
	FEEDBACK_CATEGORY,
	FEEDBACK_SUBCATEGORY,
	FEEDBACK_ITEM,
	FEEDBACK_ITEM_OPTION,
	COMMENT
) as select 
    f.source_feedback_id, 
    f.feedback_created_time, 
    f.feedback_response_time, 
    f.order_date,
    t.hour,
    t.daypart,
    f.order_number, 
    r.restaurant_number,
    ft.feedback_category,
    ft.feedback_subcategory,
    ft.feedback_item,
    ft.feedback_item_option,
    f.comment
from
    public.fact_feedback f
    left outer join public.dim_restaurant r on r.restaurant_key=f.restaurant_key
    left outer join public.dim_feedback_type ft on ft.feedback_type_key=f.feedback_type_key
    left outer join public.dim_date d on d.date_key = f.order_date_key
    left outer join public.dim_time t on t.time_key = f.order_time_key
;
