-- VIEWS: VIEW_CUSTOMER_SUMMARY
-- Generated on: 2025-06-05 11:29:25
-- Database: COSTAVIDA_DB_DEV

create or replace view VIEW_CUSTOMER_SUMMARY(
	CUSTOMER_KEY,
	CUSTOMER_NUMBER,
	SOURCE,
	LOYALTY_SIGNUP_TIME,
	IN_MARKETING_EMAIL,
	IN_MARKETING_PUSH,
	FAVORITE_RESTAURANT_NUMBER,
	DEVICE_TYPE,
	IS_CONFIRMED_EMAIL,
	LOYALTY_SIGNUP_CHANNEL,
	PUNCHH_GUEST_ID,
	IS_BANNED,
	STATUS,
	AGE_SEGMENT,
	TOTAL_BANKED_REWARDS
) as
select
  c.customer_key,
  c.customer_number,
  c.source,
  c.loyalty_signup_time,
  c.in_marketing_email,
  c.in_marketing_push,
  c.favorite_restaurant_number,
  c.device_type,
  c.is_confirmed_email,
  c.loyalty_signup_channel,
  c.punchh_guest_id,
  c.is_banned,
  c.status,
  rc.age_segment,
  g.total_banked_rewards
from
  public.dim_customer c
  join restricted.dim_customer_pii rc on rc.customer_key=c.customer_key
  join load.raw_punchh_guest g on g.user_id=c.punchh_guest_id
;
