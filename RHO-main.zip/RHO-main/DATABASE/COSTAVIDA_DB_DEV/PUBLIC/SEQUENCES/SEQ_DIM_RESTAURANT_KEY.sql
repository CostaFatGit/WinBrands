-- SEQUENCES: SEQ_DIM_RESTAURANT_KEY
-- Generated on: 2025-06-05 11:28:47
-- Database: COSTAVIDA_DB_DEV

create or replace sequence SEQ_DIM_RESTAURANT_KEY start with 1 increment by 1 order;
