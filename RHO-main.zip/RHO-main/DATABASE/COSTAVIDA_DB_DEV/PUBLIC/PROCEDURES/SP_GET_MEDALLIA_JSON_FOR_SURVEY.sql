-- PROCEDURES: SP_GET_MEDALLIA_JSON_FOR_SURVEY
-- Generated on: 2025-06-05 11:29:35
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_GET_MEDALLIA_JSON_FOR_SURVEY"("ENVIRONMENT" VARCHAR(16777216))
RETURNS TABLE ("ID" VARCHAR(100), "ORDERID" VARCHAR(100), "ORDERIDSTRING" VARCHAR(100), "EXTERNALREFERENCE" VARCHAR(100), "customer.customerId" VARCHAR(100), "customer.email" VARCHAR(100), "STORENUMBER" VARCHAR(4), "customer.firstName" VARCHAR(100), "DININGOPTION" VARCHAR(100), "TIMEREADY" VARCHAR(100))
LANGUAGE SQL
EXECUTE AS OWNER
AS '

DECLARE
  result_set RESULTSET;

BEGIN

     BEGIN TRANSACTION;

     CREATE OR REPLACE TEMPORARY TABLE  
        temp_MedalliaData
    AS
      SELECT DISTINCT
        FS.POS_ORDER_ID AS id
        ,FS.POS_ORDER_ID AS orderId
        ,FS.POS_ORDER_ID AS orderIdString
        ,FS.POS_ORDER_ID AS externalReference
        ,PC.SPENDGO_GUEST_ID AS "customer.customerId"
        ,RC.EMAIL AS "customer.email"
        ,R.RESTAURANT_NUMBER AS storeNumber
        ,RC.FIRST_NAME AS "customer.firstName"
        ,B.DINING_OPTION AS diningOption
        ,TO_CHAR(FS.ORDER_CREATED_TIME, ''YYYYMMDD HH24:MI'') AS timeReady
        ,PC.CUSTOMER_KEY
        ,FS.ORDER_NUMBER
        ,FS.DATE_KEY
        ,FS.TIME_KEY
        ,TO_DATE(FS.ORDER_CREATED_TIME) AS ORDER_DATE
        ,FS.RESTAURANT_KEY
      FROM
      (
        SELECT DISTINCT
          F.POS_ORDER_ID
         ,F.CUSTOMER_KEY
         ,F.RESTAURANT_KEY
         ,F.BEHAVIOR_KEY
         ,F.ORDER_CREATED_TIME
         ,F.ORDER_NUMBER
         ,F.DATE_KEY
         ,F.TIME_KEY
        FROM
          PUBLIC.FACT_SALES F
        WHERE
          F.ORDER_CREATED_TIME >= DATEADD(HOUR, -24, CURRENT_TIMESTAMP())
          AND F.CUSTOMER_KEY <> 0
          AND F.LOYALTY_SURVEY_REQUESTED = FALSE
      ) FS
      JOIN
        RESTRICTED.DIM_CUSTOMER_PII RC ON FS.CUSTOMER_KEY = RC.CUSTOMER_KEY AND RC.RECORD_IS_CURRENT = TRUE
      JOIN
        PUBLIC.DIM_CUSTOMER PC ON FS.CUSTOMER_KEY = PC.CUSTOMER_KEY AND PC.RECORD_IS_CURRENT = TRUE
      JOIN
        PUBLIC.DIM_RESTAURANT R ON FS.RESTAURANT_KEY = R.RESTAURANT_KEY AND R.RECORD_IS_CURRENT = TRUE
      JOIN
        PUBLIC.DIM_BEHAVIOR B ON FS.BEHAVIOR_KEY = B.BEHAVIOR_KEY AND B.RECORD_IS_CURRENT = TRUE
      WHERE
        RC.EMAIL IS NOT NULL
        AND PC.SPENDGO_GUEST_ID IS NOT NULL
        AND PC.IN_MARKETING_EMAIL = TRUE
        AND R.LOYALTY_SURVEY_ENABLED_DATETIME <= CURRENT_TIMESTAMP();

    IF (:Environment = ''PROD'') THEN

          result_set :=
          (
          SELECT
            id
           ,orderId
           ,orderIdString
           ,externalReference
           ,"customer.customerId"
           ,"customer.email"
           ,storeNumber
           ,"customer.firstName"
           ,diningOption
           ,timeReady
          FROM
            temp_MedalliaData
          );

        INSERT INTO
          PUBLIC.FACT_FEEDBACK(POS_ORDER_ID, ORDER_NUMBER, ORDER_DATE, FEEDBACK_TYPE_KEY, RESTAURANT_KEY, ORDER_DATE_KEY, ORDER_TIME_KEY, 
                               FEEDBACK_REQUESTED_TIME)
        SELECT
          T.id
         ,T.ORDER_NUMBER
         ,T.ORDER_DATE
         ,1290
         ,T.RESTAURANT_KEY
         ,T.DATE_KEY
         ,T.TIME_KEY
         ,CURRENT_TIMESTAMP()
        FROM
          temp_MedalliaData T;
        
        UPDATE
          PUBLIC.DIM_CUSTOMER C
        SET
          C.LAST_SURVEY_TIME = CURRENT_TIMESTAMP()
         ,C.NUMBER_OF_SURVEYS = C.NUMBER_OF_SURVEYS + 1
         ,C.RECORD_CHANGE_REASON = ''Loyalty Survey Requested''
         ,C.RECORD_CHANGE_TIME = CURRENT_TIMESTAMP()
        FROM
          temp_MedalliaData M
        WHERE  
          C.CUSTOMER_KEY = M.CUSTOMER_KEY;

        UPDATE
          PUBLIC.FACT_SALES F
        SET
          F.LOYALTY_SURVEY_REQUESTED = TRUE
        FROM
          temp_MedalliaData M
        WHERE
          F.POS_ORDER_ID = M.id;          

    END IF;

    IF (:Environment = ''DEV'') THEN

          result_set :=
          (
          SELECT TOP 150
            id
           ,orderId
           ,orderIdString
           ,externalReference
           ,"customer.customerId"
           ,''mark.callison@solutions-ii.com'' AS "customer.email"
           ,storeNumber
           ,"customer.firstName"
           ,diningOption
           ,timeReady
          FROM
            temp_MedalliaData
          );
    
    END IF;

    COMMIT;

    RETURN TABLE(result_set);

    EXCEPTION
        WHEN OTHER THEN
            ROLLBACK;
            RAISE;

END;
';
