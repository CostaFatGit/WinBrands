-- PROCEDURES: SP_FACT_SALES_CUSTOMER_KEY_UPDATE
-- Generated on: 2025-06-05 11:29:34
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "SP_FACT_SALES_CUSTOMER_KEY_UPDATE"()
RETURNS VARCHAR(256)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

    --Since there is no ORDERS table, the CUSTOMER_KEY for an Order can be incorrectly different
    --for different itemso on the same Order/Check.  This is because items come in late, etc.
    --We need to unify this and make sure the same Customer is credited for the same Order/Check
    --before we do the Order Summary, or we will duplicate data.

    CREATE OR REPLACE TEMPORARY TABLE TEMP_FS AS
    SELECT DISTINCT
      TO_VARCHAR(POS_ORDER_ID) AS POS_ORDER_ID
     ,TO_VARCHAR(POS_CHECK_ID) AS POS_CHECK_ID
     ,CUSTOMER_KEY AS CUSTOMER_KEY
    FROM
      PUBLIC.FACT_SALES;
    
    UPDATE PUBLIC.FACT_SALES FS
    SET FS.CUSTOMER_KEY = DT.CUSTOMER_KEY
    FROM (
        SELECT
            T.POS_ORDER_ID,
            T.POS_CHECK_ID,
            T.CUSTOMER_KEY
        FROM
            TEMP_FS T
        JOIN
            TEMP_FS T2 
            ON T.POS_ORDER_ID = T2.POS_ORDER_ID 
            AND T.POS_CHECK_ID = T2.POS_CHECK_ID 
            AND T.CUSTOMER_KEY > T2.CUSTOMER_KEY
    ) DT
    WHERE FS.POS_ORDER_ID = DT.POS_ORDER_ID 
    AND FS.POS_CHECK_ID = DT.POS_CHECK_ID
    AND FS.CUSTOMER_KEY <> DT.CUSTOMER_KEY;

END';
