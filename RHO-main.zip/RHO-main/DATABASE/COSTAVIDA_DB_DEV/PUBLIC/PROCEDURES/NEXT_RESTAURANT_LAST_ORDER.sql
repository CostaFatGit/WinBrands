-- PROCEDURES: NEXT_RESTAURANT_LAST_ORDER
-- Generated on: 2025-06-05 11:29:32
-- Database: COSTAVIDA_DB_DEV

CREATE OR REPLACE PROCEDURE "NEXT_RESTAURANT_LAST_ORDER"()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
  snowflake.execute({ sqlText: ''BEGIN TRANSACTION'' });
  key = "";

  // Get the restaurant_key of the next restaurant in queue to be polled.
  var sql_command = "select top 1 r.restaurant_key from dim_restaurant r inner join log_load_status l on l.restaurant_number=r.restaurant_number and l.pct_complete < 100 where r.status=''Active'' and record_is_current = true and toast_restaurant_id is not null and toast_restaurant_id not like '''' order by last_pos_poll_time asc";
  var stmt = snowflake.createStatement(
         {
         sqlText: sql_command
         }
      );
  var rs = stmt.execute();
  // Get the returned value
  rs.next();
  key = rs.getColumnValue(1);

  // Update the poll time for this restaurant to move it to the back of the queue.
  sql_command = "update dim_restaurant set last_pos_poll_time = current_timestamp(2) where restaurant_key=" + key;
  stmt = snowflake.createStatement(
         {
         sqlText: sql_command
         }
      );
   rs = stmt.execute();
  
  snowflake.execute({ sqlText: ''COMMIT'' }); 

  // Get the Toast ID for this restaurant
  sql_command = "select toast_restaurant_id from dim_restaurant where restaurant_key = " + key;
  stmt = snowflake.createStatement(
         {
         sqlText: sql_command
         }
      );
  rs = stmt.execute();
  // Get the returned values
  rs.next();
  toast_restaurant_id = rs.getColumnValue(1);

  // Get the last order date for this restaurant
  sql_command = "select to_varchar(max(order_modified_time), ''YYYY-MM-DDTHH24:MI:SS.FF3TZHTZM'') as last_order_modified_time from fact_sales where restaurant_key = " + key;
  stmt = snowflake.createStatement(
         {
         sqlText: sql_command
         }
      );
  rs = stmt.execute();
  // Get the returned values
  rs.next();
  last_order_modified_time = rs.getColumnValue(1);

  return toast_restaurant_id + "|" + last_order_modified_time;
  ';
